Delta = 2; % TIME BETWEEN OBSERVATIONS
load drifterbetty2.mat
XX = drifterbetty.cv; X=(XX(4201:4800)); % TIME SERIES
YY = drifterbetty.f; YY = -4*pi*YY; CF = mean(YY(4201:4800)); % CORIOLIS FREQUENCIES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PRELIMINARIES
N = length(X); omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi;
SZ=(Delta/N)*(abs(fft(X))).^2; SZ=fftshift(SZ); % Spectrum
%% FIGURES
ed=0.2;
Fig2R=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 400.0]);
plot(omega,10*log10(SZ),'g'); xlim([-pi pi]); % figure of periodogram
ylim([-20 60]);
hold on; line([CF CF],[-20 60],'color','r');
xlabel('\omega\Delta'); ylabel('dB');
exportfig(Fig2R, 'Fig2R.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper