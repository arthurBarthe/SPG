Fig1R=figure;
load drifterbetty2.mat
XX = drifterbetty.lon+1i.*drifterbetty.lat; 
Z=(XX(1901:4900)); % TIME SERIES
plot(Z,'color',[.7 .7 .7]);
X=(XX(2971:3570)); % TIME SERIES BLUE PORTION
hold on; plot(X,'b');
Y=(XX(4201:4800)); % TIME SERIES RED PORTION
hold on; plot(Y,'g');
xlabel('Longitude'); ylabel('Latitude');
ax = gca;
ax.XTick = [-71,-70,-69,-68,-67,-66];
ax.YTick = [32,33,34,35,36,37];
xlim([-72 -65]); ylim([31 38]);
axis square
exportfig(Fig1R, 'Fig1R.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper