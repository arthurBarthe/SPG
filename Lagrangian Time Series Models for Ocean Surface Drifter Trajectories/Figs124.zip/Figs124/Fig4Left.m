Delta = 2; % TIME BETWEEN OBSERVATIONS
options=optimset('GradObj','on','MaxFunEvals',100000,'MaxIter',100000,'TolFun',1e-10,'TolX',1e-10,'Display','off'); % Fminsearch choices
LPCNT=0.4; % Fraction of negative frequencies included in fit (from 0 to 1)
UPCNT=0; % Fraction of positive frequencies included in fit (from 0 to 1)
ZEROF=0; % Include zero-frequency? 1=yes, 0=no;
load drifterbetty2.mat
XX = drifterbetty.cv; X=(XX(2971:3570)); % TIME SERIES
YY = drifterbetty.f; YY = -4*pi*YY; CF = mean(YY(2971:3570)); % CORIOLIS FREQUENCIES
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% PRELIMINARIES
N = length(X); omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi;
MF = floor(N/2)+1; LB = round((MF-1)*(1-LPCNT)+1); UB = round(MF+UPCNT*(N-MF));
SZ=(Delta/N)*(abs(fft(X))).^2; SZ=fftshift(SZ); % Spectrum
%% INITIAL PARAMETERS
xb=zeros(1,6);
valMF = SZ(MF); xb(5)=1; valMAX = max(SZ); IF=round(N*0.5*(1+0.5*CF/pi)); 
if CF > 0
    [dum1,fmax] = max(SZ(IF:N)); fmax=fmax+IF-1;
else
    [dum1,fmax] = max(SZ(1:IF));
end
NF=floor((abs(MF-fmax))/3);
xb(6)=quantile(SZ([MF-NF:MF-1 MF+1:MF+NF]).*(omega([MF-NF:MF-1 MF+1:MF+NF]))'.^2./(valMAX-SZ([MF-NF:MF-1 MF+1:MF+NF])),0.5);
xb(4)=valMAX*xb(6); xb(4) = abs(xb(4))^0.5; xb(6) = abs(xb(6))^0.5; % square root of these to arrive at starting parameters
valmax = SZ(fmax); xb(2)=CF; % corresponding frequency peak in radians
xb(3)=quantile(SZ([fmax-NF:fmax-1 fmax+1:fmax+NF]).*(omega([fmax-NF:fmax-1 fmax+1:fmax+NF])-xb(2))'.^2./(valmax-SZ([fmax-NF:fmax-1 fmax+1:fmax+NF])),0.5);
xb(1)=valmax*xb(3); % and the amplitude parameter
xb(1) = abs(xb(1))^0.5; xb(3) = abs(xb(3))^0.5; % square root of these to arrive at starting parameters
%% LIKELIHOOD
tic; [x1b,fval1,exitflag1]=fminsearchbnd(@(x) maternOUmodel(x,xb,SZ',N,LB,UB,MF,ZEROF),[1 1 1 1 1 1],[0 -inf pi*sqrt(3)/(N*xb(3)) 0 0.5 pi*sqrt(3)/(N*xb(6))],[inf inf inf inf inf inf],options); time=toc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% OUTPUT
x1 = x1b.*xb;
%% FIGURES
ed=0.19;
Fig4L=figure; plot(omega,10*log10(SZ),'b'); xlim([-pi pi]); % figure of periodogram
acv=maternacvs(x1(4:6),N,1)+complexouacvs(x1(1:3),N,1); % predicted autocovariance sequence
ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF3=abs(real(fftshift(ESF2))); % fft of acvs with triangle kernel to find expected blurred spectrum
hold on; plot(omega,10*log10(ESF3),'color','r','linestyle','--','linewidth',2); % plot of this over periodogram
hold on; plot(omega(LB:UB),10*log10(ESF3(LB:UB)),'g','linewidth',2); % plot of this over periodogram
hold on; line([CF CF],[-20 60],'color','k'); ylim([-20 60]);
hold on; line([ed ed],[-20 60],'color','k','linestyle','--');
hold on; line([CF-ed CF-ed],[-20 60],'color','k','linestyle','--');
legend('data','model fit','model fit: \omega\Delta\in\Omega')
xlabel('\omega\Delta'); ylabel('dB');
exportfig(Fig4L, 'Fig4L.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper