%% Preliminaries
Q=[10 0.9 .1]; Delta=1; N=1000; % Q are the Matern parameters (B,\alpha,h), Delta is the time-step in hours, N is the length
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % fourier coefficients, correct for odd or even N
%% generating Matern
tpz = maternacvs(Q,N,Delta); % autocovariance sequence
T=transpose(chol(toeplitz(tpz))); % traspose to make lower triangle, chol is cholesky, toeplitz to make matrix from regularly sampled data
rng(21); Z=randn(N,2); XX=T*Z; XX=XX./sqrt(2); % multiply by random Gaussian for each axis (real and imaginary), so we need to normalise by sqrt(2) to get the right variance
%% generating fBm
C=-gamma(2-2*(Q(2)-0.5))*cos(pi*(Q(2)-0.5))/(pi*(Q(2)-0.5)*(2*Q(2)-2));
cmx=zeros(N,N);
for i =1:N
    for j = 1:N
        cmx(i,j) = ((i*Delta)^(2*Q(2)-1)+(j*Delta)^(2*Q(2)-1)-abs(Delta*(i-j))^(2*Q(2)-1));
    end
end
cmx = (C*Q(1)^2)*cmx/2;
Tf = transpose(chol(cmx));
XXf=Tf*Z; XXf=XXf./sqrt(2); % multiply by random Gaussian for each axis (real and imaginary), so we need to normalise by sqrt(2) to get the right variance
%% Time Series and Spectrum
Y=XX(:,1)+1i*XX(:,2); % Complex-valued time series
SZ=(Delta/N)*(abs(fft(Y))).^2; SZ=fftshift(SZ); % Periodogram, multiply by Delta to be unitless
Xf=XXf(:,1)+1i*XXf(:,2); % Complex-valued time series
SZf=(Delta/N)*(abs(fft(Xf))).^2; SZf=fftshift(SZf); % Periodogram, multiply by Delta to be unitless
%% Figure 1 in Paper
Fig3C=figure; a=max(max(XXf)); b=min(min(XXf)); c = max([a -b]);
subplot(2,2,1); plot(XXf(:,1)); ylim([-100*ceil(c/100) 100*ceil(c/100)]); 
xlabel('t\Delta'); ylabel('u (cm/s)'); hold on; plot(XX(:,1),'r'); 
legend('fBm',sprintf('Mat%crn',char(233)),'location','NorthWest');
ax = gca;
ax.XTick = [0,200,400,600,800,1000];
ax.YTick = [-200,-100,0,100,200];
subplot(2,2,2); plot(XXf(:,1),XXf(:,2)); hold on; plot(XX(:,1),XX(:,2),'r');
xlim([-100*ceil(c/100) 100*ceil(c/100)]); ylim([-100*ceil(c/100) 100*ceil(c/100)]);
xlabel('u (cm/s)'); ylabel('v (cm/s)');
legend('fBm',sprintf('Mat%crn',char(233)),'location','NorthWest');
ax = gca;
ax.XTick = [-200,-100,0,100,200];
ax.YTick = [-200,-100,0,100,200];
h=subplot(2,2,[3 4]); plot(omega,10*log10(SZf)); xlim([-pi pi]); % figure of periodogram
hold on; plot(omega,10*log10(SZ),'r'); xlabel('\omega\Delta'); ylabel('dB')
legend('fBm',sprintf('Mat%crn',char(233)),'location','NorthWest');
p = get(h, 'pos'); p(2) = p(2) + 0.05; set(h, 'pos', p);
%%
exportfig(Fig3C, 'Fig3C.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper