function [out]=maternOUmodel(x,xb,SX,N,LB,UB,MF,ZEROF)
% Computes the value of the Whittle likelihood for value x.*xb (rescaled
% back to normal units) for periodogram SX, data length N
% LB is the lowest frequency fitted, UB is the highest
% MF is the location of the zero frequency and ZEROF determines if the
% zero-frequency is included in the likelihood
acv=maternacvs(x(4:6).*xb(4:6),N,1)+complexouacvs(x(1:3).*xb(1:3),N,1); % autocovariance sequence
ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF3=abs(real(fftshift(ESF2))); % blurred spectrum
% Whittle likelihood, depending on whether we include 0 or not.
if ZEROF==0
    out=sum(log(ESF3([LB:MF-1 MF+1:UB])))+sum(SX([LB:MF-1 MF+1:UB])./ESF3([LB:MF-1 MF+1:UB]));
else
    out=sum(log(ESF3([LB:UB])))+sum(SX([LB:UB])./ESF3([LB:UB]));
end