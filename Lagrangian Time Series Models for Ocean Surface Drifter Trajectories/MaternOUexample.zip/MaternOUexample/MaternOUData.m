function[X]=MaternOUData(Q,N)
% Generating complex-valued stochastic data from the Matern + complex OU
% model, using order N^3 Cholesky method
% Q(1:3) are the inertial amplitude, frequency and damping parameters
% Q(4:6) are the matern amplitude, slope and damping parameters
% N is the data length
tpz = maternacvs(Q(4:6),N,1);
T=transpose(chol(toeplitz(tpz))); Z=randn(N,1)+1i.*randn(N,1); XX=T*Z; XX=XX./sqrt(2);
tpz2=complexouacvs(Q(1:3),N,1);
T2=transpose(chol(toeplitz(tpz2))); Z2=randn(N,1)+1i.*randn(N,1); XX2=T2*Z2; XX2=XX2./sqrt(2);
X = XX+XX2;

% Example: Run X=MaternOUData([10 -0.6 0.1 10 1.25 0.1],1000)
% and then MaternOUFit(X,-0.5,1,1,1,1) to fit the parameters from this
% process (notice that with an incorrectly specified Coriolis frequency we
% still recover the true value, so we can spot shifts in the inertial frequency this way)