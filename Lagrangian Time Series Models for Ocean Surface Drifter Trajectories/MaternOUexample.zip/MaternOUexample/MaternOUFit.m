function [out] = MaternOUFit(X,CF,Delta,LPCNT,UPCNT,ZEROF)
% X is data
% CF is the location of the Coriolis Frequency in radians per unit cycle
% Delta is the time interval in the units you want your output
% LPCT/UPCNT is the fraction of negative and positive rotary frequencies included (1=ALL, 0=NONE, 0.5=HALF ETC)
% They can be set differently to accommodate 1-sided fits
% ZEROF: include zero frequency in estimation? 1=yes, 0=no
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% These are the choices for fminsearchbnd. GradObj is Gradient descent
% (rather than Nelded Mead) and the tolerances are set low as this is all
% so fast anyway
options=optimset('GradObj','on','MaxFunEvals',100000,'MaxIter',100000,'TolFun',1e-10,'TolX',1e-10); % Fminsearch choices
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% CALCULATIONS
N = length(X); 
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % Fourier frequencies
MF = floor(N/2)+1; LB = round((MF-1)*(1-LPCNT)+1); UB = round(MF+UPCNT*(N-MF)); % Locations in omega of our frequency range for estimation
SZ=(Delta/N)*(abs(fft(X))).^2; SZ=fftshift(SZ); % Periodogram
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% INITIAL PARAMETERS
% xb is a length 6 vector of the initial parameters for fminsearch.
xb=zeros(1,6);
% xb(1:3) are the inertial amplitude, frequency and damping parameters
xb(2)=CF; % our starting guess for xb(2) is the Coriolis frequency
IObnd=round(MF*(1+0.5*CF/pi)); %  Location in omega where we form a boundary between the inertial and background regions, found by taking half of the Coriolis Freq.
if CF > 0 % IOmax and IOloc are the value and location in omega of the max ebergy inertial frequency (where IObnd is the lowest possible frequency)
    [IOmax,IOloc] = max(SZ(IObnd:N)); IOloc=IOloc+IObnd-1;
else % if statement required such that we search on the correct side of the spectrum
    [IOmax,IOloc] = max(SZ(1:IObnd));
end
NF=floor((abs(MF-IOloc))/3); % Number of frequencies used either side of the peak to fit parameters (1/3 of the distance between the 2 peaks)
xb(3)=sqrt(median(SZ([IOloc-NF:IOloc-1 IOloc+1:IOloc+NF]).*(omega([IOloc-NF:IOloc-1 IOloc+1:IOloc+NF])-xb(2))'.^2./(IOmax-SZ([IOloc-NF:IOloc-1 IOloc+1:IOloc+NF]))));
xb(1)=sqrt(IOmax)*xb(3);
% xb(1) and xb(3) found by solving simultaneous equations of the OU spectral model
% at the peak and neighbouring values (and then taking the median of these)
% xb(4:6) are the matern amplitude, slope and damping parameters
xb(5)=1; % starting slope parameter assumed to be 1 (i.e. f^-2 decay)
valMAX = max(SZ); % max value in the spectrum
xb(6)=sqrt(median(SZ([MF-NF:MF-1 MF+1:MF+NF]).*(omega([MF-NF:MF-1 MF+1:MF+NF]))'.^2./(valMAX-SZ([MF-NF:MF-1 MF+1:MF+NF]))));
xb(4)=sqrt(valMAX)*xb(6); % xb(4) and xb(6) are found in the same way as xb(1) and xb(3)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% BLURRED WHITTLE LIKELIHOOD
tic; % using fminsearchbnd, the parameters are rescaled to all start at 1, lower and upper bounds as permitted by the stochastic process
[x1b,fval1,exitflag1]=fminsearchbnd(@(x) maternOUmodel(x,xb,SZ',N,LB,UB,MF,ZEROF),[1 1 1 1 1 1],[0 -pi 0 0 0.5 0],[inf pi inf inf inf inf],options);
x1 = x1b.*xb; % scale back to correct units
time=toc;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% OUTPUT
format short
disp(['OU Amplitude = ',num2str(x1(1))])
disp(['OU Frequency = ',num2str(x1(2))])
disp(['OU Damping = ',num2str(x1(3))])
disp(['Matern Amplitude = ',num2str(x1(4))])
disp(['Matern Slope = ',num2str(x1(5))])
disp(['Matern Damping = ',num2str(x1(6))])
if exitflag1 == 1
    disp(['Optimisation converged in ',num2str(time),' seconds'])
elseif exitflag == 0
    display('Maximum number of function evaluations or iterations was reached')
else
    display('Algorithm was terminated by the output function')
end