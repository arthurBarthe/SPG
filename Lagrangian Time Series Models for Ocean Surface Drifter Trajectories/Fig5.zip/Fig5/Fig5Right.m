%% Preliminaries
Delta=1; N=1201; % Q are the Parameters (A, \omega_0, \lambda, B,\alpha,h), Delta is the time-step in hours, N is the length
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % fourier coefficients, correct for odd or even N
options=optimset('GradObj','on','MaxFunEvals',100000,'MaxIter',100000,'TolFun',1e-10,'TolX',1e-10); % some options for fminsearch, Gradient method used for likelihood
load newinertial.mat
BLFIT = zeros(1201,200); SPEC=zeros(1201,200);
for ii = 1:200
    ii
X = newinertial.drifters.u(:,ii)+1i*newinertial.drifters.v(:,ii); ZEROF=1;
A1 = mean(newinertial.drifters.lat(1:1201,ii));
B1=(8*pi/23.9345)*sin(A1*pi/180);
smp=1.5*B1/pi; MF = floor(N/2)+1; LB = round((MF-1)*(1-smp)+1); UB = N+1-LB;
%% Time Series and Spectrum
SZ=(Delta/N)*(abs(fft(X))).^2; SZ=fftshift(SZ); % Periodogram, multiply by Delta to be unitless
%% Starting values using least squares on one side of spectrum for Matern (non-inertial side) and then simultaneous equations for complex-OU
xb=zeros(1,6);
valMF = SZ(MF); xb(5)=1; valMAX = max(SZ); [dum1,fmax] = max(SZ(1:500)); NF=floor((MF-fmax)/3);
xb(6)=quantile(SZ([MF-NF:MF-1 MF+1:MF+NF]).*(omega([MF-NF:MF-1 MF+1:MF+NF]))'.^2./(valMAX-SZ([MF-NF:MF-1 MF+1:MF+NF])),0.8);
xb(4)=valMAX*xb(6); xb(4) = abs(xb(4))^0.5; xb(6) = abs(xb(6))^0.5; % square root of these to arrive at starting parameters
valmax = SZ(fmax); xb(2)=omega(fmax); % correspondingfreq uency peak in radians
xb(3)=quantile(SZ([fmax-NF:fmax-1 fmax+1:fmax+NF]).*(omega([fmax-NF:fmax-1 fmax+1:fmax+NF])-xb(2))'.^2./(valmax-SZ([fmax-NF:fmax-1 fmax+1:fmax+NF])),0.8);
xb(1)=valmax*xb(3); % and the amplitude parameter
xb(1) = abs(xb(1))^0.5; xb(3) = abs(xb(3))^0.5; % square root of these to arrive at starting parameters
%% Whittle likelihood (Details in Inertial Paper, Section 3a)
x1b=fminsearchbnd(@(x)maternOUmodel(x,xb,SZ',N,LB,UB,MF,ZEROF),[1 1 1 1 1 1],[0 -inf pi*sqrt(3)/(N*xb(3)) 0 0.5 pi*sqrt(3)/(N*xb(6))],[inf inf inf inf inf inf],options);
x1=x1b.*xb;
%% Plots over different types of spectra, to show why we use the blurred likelihood
acv=maternacvs(x1(4:6),N,1)+complexouacvs(x1(1:3),N,1); % predicted autocovariance sequence
ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF3=abs(real(fftshift(ESF2))); % fft of acvs with triangle kernel to find expected blurred spectrum
BLFIT(:,ii)=ESF3; SPEC(:,ii)=SZ;
end
%%
Fig5B = figure; box on
hold on; plot(omega,10*log10(mean(SPEC')),'b');
hold on; plot(omega,10*log10(mean(BLFIT')),'color','r','linestyle','--','linewidth',2); % plot of this over periodogram
hold on; plot(omega(LB:UB),10*log10(mean(BLFIT(LB:UB,:)')),'g','linewidth',2); % plot of this over periodogram
legend('mean periodogram','mean model fit','mean model fit: \omega\Delta\in\Omega');
hold on; plot(omega,10*log10(SPEC'),'color',[.7 .7 .7]);
hold on; plot(omega,10*log10(BLFIT'),'color',[.5 .5 .5]);
hold on; plot(omega,10*log10(mean(SPEC')),'b');
hold on; plot(omega,10*log10(mean(BLFIT')),'color','r','linestyle','--','linewidth',2); % plot of this over periodogram
hold on; plot(omega(LB:UB),10*log10(mean(BLFIT(LB:UB,:)')),'g','linewidth',2); % plot of this over periodogram
xlim([-pi pi]); ylim([-40 60]); xlabel('\omega\Delta'); ylabel('dB');
exportfig(Fig5B, 'Fig5B.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper