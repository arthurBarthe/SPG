load Ulysses6p.mat
N=1000;
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % fourier coefficients, correct for odd or even N
load drifterulysses.mat
YY = drifterulysses.f; YY = 4*pi*YY;
A1 = max(YY); smp=1.75*A1/pi;
MF = floor(N/2)+1; LB = round((MF-1)*(1-smp)+1); UB = N+1-LB; LB = MF+1;
LL=length(Ulysses6p.cf);
CLIM = [20 60]; scrsz = get(0,'ScreenSize'); Fig7A=figure('Position',[1 1 1.3*scrsz(3)/2.6 1.3*scrsz(3)/6.8]);
imagesc(500/12+(1:LL)/12,omega(LB:UB),10*log10(Ulysses6p.spec(:,LB:UB))',CLIM); colorbar;
ylabel('Frequency in radians');  colormap('jet'); set(gca,'YDir','normal')
ax = gca;
ax.YTick = [0.2,0.4,0.6,0.8,1.0];
hold on; plot(500/12+(1:LL)/12,Ulysses6p.cf(1:LL),'w');
exportfig(Fig7A, 'Fig7A.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper
%%
CLIM = [20 60]; scrsz = get(0,'ScreenSize'); Fig7B=figure('Position',[1 1 1.3*scrsz(3)/2.6 1.3*scrsz(3)/6.8]); 
imagesc(500/12+(1:LL)/12,omega(LB:UB),10*log10(Ulysses6p.mod(:,LB:UB))',CLIM); colorbar;
ylabel('Frequency in radians'); xlabel('Day');  colormap('jet'); set(gca,'YDir','normal')
ax = gca;
ax.YTick = [0.2,0.4,0.6,0.8,1.0];
hold on; plot(500/12+(1:LL)/12,Ulysses6p.cf(1:LL),'w');
exportfig(Fig7B, 'Fig7B.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper