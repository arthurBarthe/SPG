load Ulysses5p.mat
load Ulysses6p.mat
LL=length(Ulysses6p.cf);
%%
scrsz = get(0,'ScreenSize'); Fig8B=figure('Position',[1 1 800 250]);
plot(500/12+(1:LL)/12,Ulysses6p.param(:,1),'b'); hold on; plot(500/12+(1:LL)/12,Ulysses6p.param(:,4),'r'); legend('OU amplitude: A','Matern amplitude: B','location','North');
boundedline(500/12+(1:LL)/12,Ulysses6p.param(:,1),1.96*sqrt(Ulysses6p.var(1:LL,1,1)),'b'); 
hold on; boundedline(500/12+(1:LL)/12,Ulysses6p.param(:,4),1.96*sqrt(Ulysses6p.var(1:LL,4,4)),'r');
axis([501/12 500/12+LL/12 0 max(max(Ulysses6p.param(:,1),Ulysses6p.param(:,4)))+4]);
ax = gca;
set(gca,'yticklabel',num2str(get(gca,'ytick')','%.1f'))
ax.YTick = [0,5.0,10.0,15.0,20.0,25.0];
exportfig(Fig8B, 'Fig8B.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper
%%
scrsz = get(0,'ScreenSize'); Fig8C=figure('Position',[1 1 800 250]); 
plot(500/12+(1:LL)/12,Ulysses6p.param(:,3),'b'); hold on; plot(500/12+(1:LL)/12,Ulysses6p.param(:,6),'r'); legend('OU damping: c','Matern damping: h','location','North');
hold on; boundedline(500/12+(1:LL)/12,Ulysses6p.param(:,6),1.96*sqrt(Ulysses6p.var(1:LL,6,6)),'r');
boundedline(500/12+(1:LL)/12,Ulysses6p.param(:,3),1.96*sqrt(Ulysses6p.var(1:LL,3,3)),'b');
axis([501/12 500/12+LL/12 0 max(max(Ulysses6p.param(:,3),Ulysses6p.param(:,6)))+0.07]);
hold on; plot(500/12+(1:LL)/12,Ulysses6p.param(:,6),'r');
ax = gca;
ax.YTick = [0,0.04,0.08,0.12,0.16];
set(gca,'yticklabel',num2str(get(gca,'ytick')','%.2f'))
exportfig(Fig8C, 'Fig8C.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper
%%
scrsz = get(0,'ScreenSize'); Fig8D=figure('Position',[1 1 800 250]); 
plot(500/12+(1:LL)/12,Ulysses6p.param(:,5),'b'); legend('Slope parameter: \alpha','location','North');
boundedline(500/12+(1:LL)/12,Ulysses6p.param(:,5),1.96*sqrt(Ulysses6p.var(1:LL,5,5)),'b'); 
axis tight;  xlabel('Day');
ax = gca;
ax.YTick = [0.60,0.80,1.00,1.20,1.40];
set(gca,'yticklabel',num2str(get(gca,'ytick')','%.2f'))
set(gca,'OuterPosition',[0 0.01 1 1])
exportfig(Fig8D, 'Fig8D.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper
%%
scrsz = get(0,'ScreenSize'); Fig8A=figure('Position',[1 1 800 250]);
plot(500/12+(1:LL)/12,Ulysses6p.param(1:LL,2),'b'); hold on; plot(500/12+(1:LL)/12,Ulysses6p.cf(1:LL),'r');
lgnd=legend('Estimated inertial frequency: \omega_0','Coriolis frequency: f','Location','North');
boundedline(500/12+(1:LL)/12,Ulysses6p.param(1:LL,2),1.96*sqrt(Ulysses6p.var(1:LL,2,2)),'b'); 
axis([501/12 500/12+LL/12 min(min(Ulysses6p.param(:,2),Ulysses6p.cf')) max(max(Ulysses6p.param(:,2),Ulysses6p.cf'))+0.013]);
hold on; plot(500/12+(1:LL)/12,Ulysses6p.cf(1:LL),'r');
ax = gca;
ax.YTick = [0.45,0.50,0.55,0.60,0.65];
set(gca,'yticklabel',num2str(get(gca,'ytick')','%.2f')); ylim([0.43 0.67]);
exportfig(Fig8A, 'Fig8A.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper
%%
SC5=max(Ulysses5p.score1,Ulysses5p.score2);
SC6=max(Ulysses6p.score1,Ulysses6p.score2);
scrsz = get(0,'ScreenSize'); Fig9=figure('Position',[1 1 800 250]); plot(500/12+(1:LL)/12,2*(SC5-SC6),'b')
hold on; line([501/12 (500+LL)/12],[chi2inv(0.95,1) chi2inv(0.95,1)],'color','r','linestyle','--'); axis tight
legend('R(t)','95% confidence'); xlabel('Day')
set(gca,'OuterPosition',[0 0.01 1 1])
exportfig(Fig9, 'Fig9.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper