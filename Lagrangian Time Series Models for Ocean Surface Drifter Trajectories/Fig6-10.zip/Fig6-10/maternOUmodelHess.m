function [out]=maternOUmodelHess(x,SX,N,LB,UB,MF,ZEROF)
A=x(4:6); B=x(1:3);
A=max(0,A); A(2)=max(0.5,A(2)); B(1)=max(0,B(1)); B(3)=max(0,B(3));
acv=maternacvs(A,N,1)+complexouacvs(B,N,1);
ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF3=abs(real(fftshift(ESF2)));
if ZEROF==0
    out=sum(log(ESF3([LB:MF-1 MF+1:UB])))+sum(SX([LB:MF-1 MF+1:UB])./ESF3([LB:MF-1 MF+1:UB]));
else
    out=sum(log(ESF3([LB:UB])))+sum(SX([LB:UB])./ESF3([LB:UB]));
end