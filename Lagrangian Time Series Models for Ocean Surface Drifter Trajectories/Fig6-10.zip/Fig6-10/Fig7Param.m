%% Preliminaries
Q=[10 -pi/4 .1 10 1.1 .1]; Delta=2; N=1000; % Q are the Parameters (A, \omega_0, \lambda, B,\alpha,h), Delta is the time-step in hours, N is the length
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % fourier coefficients, correct for odd or even N
options=optimset('GradObj','on','MaxFunEvals',100000,'MaxIter',100000,'TolFun',1e-10,'TolX',1e-10); % some options for fminsearch, Gradient method used for likelihood
load drifterulysses.mat
XX = drifterulysses.cv; YY = drifterulysses.f; YY = 4*pi*YY;
A1 = max(YY); smp=1.75*A1/pi;
MF = floor(N/2)+1; LB = round((MF-1)*(1-smp)+1); UB = N+1-LB; LB = MF+1;
Ulysses6p=[]; Ulysses5p=[];
for ii =1:length(XX)-N+1;
    ii
X = (XX(ii:ii+N-1)); CF = mean(YY(ii:ii+N-1));
%% Time Series and Spectrum
SZ=(Delta/N)*(abs(fft(X))).^2; SZ=fftshift(SZ); % Periodogram, multiply by Delta to be unitless
%% Starting values using least squares on one side of spectrum for Matern (non-inertial side) and then simultaneous equations for complex-OU
xb=zeros(1,6);
valMF = SZ(MF); xb(5)=1; valMAX = max(SZ); IF=round(N*0.5*(1+0.5*CF/pi)); [dum1,fmax] = max(SZ(IF:N)); fmax=fmax+IF-1; NF=floor((abs(MF-fmax))/3);
xb(6)=quantile(SZ([MF-NF:MF-1 MF+1:MF+NF]).*(omega([MF-NF:MF-1 MF+1:MF+NF]))'.^2./(valMAX-SZ([MF-NF:MF-1 MF+1:MF+NF])),0.8);
xb(4)=valMAX*xb(6); % and the amplitude parameter
xb(4) = abs(xb(4))^0.5; xb(6) = abs(xb(6))^0.5; % square root of these to arrive at starting parameters
valmax = SZ(fmax); xb(2)=CF; % correspondingfreq uency peak in radians
xb(3)=quantile(SZ([fmax-NF:fmax-1 fmax+1:fmax+NF]).*(omega([fmax-NF:fmax-1 fmax+1:fmax+NF])-xb(2))'.^2./(valmax-SZ([fmax-NF:fmax-1 fmax+1:fmax+NF])),0.8);
xb(1)=valmax*xb(3); % and the amplitude parameter
xb(1) = abs(xb(1))^0.5; xb(3) = abs(xb(3))^0.5; % square root of these to arrive at starting parameters
if ii>1
    xb2=x1; xb3=x2;
else
    xb2=xb; xb3=xb;
end
%% Whittle likelihood (Details in Inertial Paper, Section 3a)
[x1b,fval1,exitflag1]=fminsearchbnd(@(x) maternOUmodel(x,xb,SZ',N,LB,UB,MF,0),[1 1 1 1 1 1],[0 0 pi*sqrt(3)/(N*xb(3)) 0 0.5 pi*sqrt(3)/(N*xb(6))],[inf inf inf inf inf inf],options);
[x1b2,fval2,exitflag2]=fminsearchbnd(@(x) maternOUmodel(x,xb2,SZ',N,LB,UB,MF,0),[1 1 1 1 1 1],[0 0 pi*sqrt(3)/(N*xb2(3)) 0 0.5 pi*sqrt(3)/(N*xb2(6))],[inf inf inf inf inf inf],options);
if fval1<fval2
    x1=x1b.*xb;
    whittle=@(x) maternOUmodelHess(x,SZ',N,LB,UB,MF,0);
    FI=hessian(whittle,x1); IFI = inv(FI);
    Ulysses6p.ef(ii)=exitflag1; Ulysses6p.efo(ii)=exitflag2; Ulysses6p.sw(ii)=1;
else
    x1=x1b2.*xb2;
    whittle=@(x) maternOUmodelHess(x,SZ',N,LB,UB,MF,0);
    FI=hessian(whittle,x1); IFI = inv(FI);
    Ulysses6p.ef(ii)=exitflag2; Ulysses6p.efo(ii)=exitflag1;  Ulysses6p.sw(ii)=0;
end
acv=maternacvs(x1(4:6),N,1)+complexouacvs(x1(1:3),N,1); % predicted autocovariance sequence
ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF3=abs(real(fftshift(ESF2))); % fft of acvs with triangle kernel to find expected blurred spectrum
Ulysses6p.cf(ii)=CF; Ulysses6p.param(ii,:)=x1; Ulysses6p.spec(ii,:)=SZ; Ulysses6p.mod(ii,:)=ESF3; 
Ulysses6p.score1(ii)=maternOUmodel(x1b,xb,SZ',N,LB,UB,MF,0); Ulysses6p.score2(ii)=maternOUmodel(x1b2,xb2,SZ',N,LB,UB,MF,0);
Ulysses6p.var(ii,:,:)=IFI; 
Ulysses6p.param(ii,:)
%%
[x2b,fval1,exitflag1]=fminsearchbnd(@(x) maternOUmodel(x,xb,SZ',N,LB,UB,MF,0),[1 1 1 1 1 1],[0 1 pi*sqrt(3)/(N*xb(3)) 0 0.5 pi*sqrt(3)/(N*xb(6))],[inf 1 inf inf inf inf],options);
[x2b2,fval2,exitflag2]=fminsearchbnd(@(x) maternOUmodel(x,[xb3(1) CF xb3(3:6)],SZ',N,LB,UB,MF,0),[1 1 1 1 1 1],[0 1 pi*sqrt(3)/(N*xb2(3)) 0 0.5 pi*sqrt(3)/(N*xb2(6))],[inf 1 inf inf inf inf],options);
if fval1<fval2
    x2=x2b.*xb;
    Ulysses5p.ef(ii)=exitflag1; Ulysses5p.efo(ii)=exitflag2; Ulysses5p.sw(ii)=1;
else
    x2=x2b2.*[xb3(1) CF xb3(3:6)];
    Ulysses5p.ef(ii)=exitflag2; Ulysses5p.efo(ii)=exitflag1;  Ulysses5p.sw(ii)=0;
end
acv=maternacvs(x2(4:6),N,1)+complexouacvs(x2(1:3),N,1); % predicted autocovariance sequence
ESF2=2*fft(acv.*(1-(0:N-1)/N))-acv(1); ESF3=abs(real(fftshift(ESF2))); % fft of acvs with triangle kernel to find expected blurred spectrum
Ulysses5p.cf(ii)=CF; Ulysses5p.param(ii,:)=x2; Ulysses5p.spec(ii,:)=SZ; Ulysses5p.mod(ii,:)=ESF3; 
Ulysses5p.score1(ii)=maternOUmodel(x2b,xb,SZ',N,LB,UB,MF,0); Ulysses5p.score2(ii)=maternOUmodel(x2b2,[xb3(1) CF xb3(3:6)],SZ',N,LB,UB,MF,0);
Ulysses5p.param(ii,:)
end
%%
save('Ulysses6p.mat','Ulysses6p')
save('Ulysses5p.mat','Ulysses5p')