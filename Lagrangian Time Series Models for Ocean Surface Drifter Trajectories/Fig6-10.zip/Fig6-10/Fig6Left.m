Fig6A=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 400.0]);
load drifterulysses.mat
XX = drifterulysses.lon+1i.*drifterulysses.lat; 
Z=XX; % TIME SERIES
plot(Z,'b');
hold on; plot(Z(350*12+1:370*12),'r','linewidth',2);
xlabel('Longitude'); ylabel('Latitude');
ax = gca;
ax.XTick = [-120,-110,-100,-90,-80];
ax.YTick = [-40,-30,-20];
xlim([-121 -79]); ylim([-41 -19]);
set(gca,'OuterPosition',[0 0.01 1 1])
exportfig(Fig6A, 'Fig6A.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18); % For exporting fig into paper