function [out]=likelihoodmaternDMP(x,nu,X,N)
amp=sqrt(sqrt(pi)*2*x^(2*nu)*(gamma(nu+.5)/gamma(nu))); % amplitude parameter is function of unknown damping parameter
acv=maternacvs([amp nu+.5 x],N); % autocovariance sequence
C=toeplitz(acv); % covariance matrix
L = chol(C); % Cholesky for determinant and inverse
logdetC = 2*sum(log(diag(L))); % log-determinant
Cinv = inv(L)/L'; % inverse
out=0.5*logdetC+0.5*X'*Cinv*X; % likelihood