function [out]=l2witt(x,nu,SX,N)
amp=sqrt(sqrt(pi)*2*x^(2*nu)*(gamma(nu+.5)/gamma(nu))); % amplitude
omega=0:2*pi/N:2*pi*(1-1/N);
omega(N-floor(N/2)+1:N)=omega(N-floor(N/2)+1:N)-2*pi; % Fourier frequencies
ESF3=amp^2./(omega.^2+x^2).^(nu+.5); % continuous-time spectrum
out=sum(log(ESF3))+sum(SX./ESF3); % Whittle likelihood