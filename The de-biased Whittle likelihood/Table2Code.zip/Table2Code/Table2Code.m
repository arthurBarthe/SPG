% Preliminaries
% set the same as seed in ScalaGauss package
RandStream.setGlobalStream(RandStream('mt19937ar','seed',1420));
M = 100; % number of repeats (10,000 in paper, make smaller for a quicker run)
CC=randn(M,1024); save('CC.mat','CC'); % save random numbers
EXP1=[]; EXP1.FD1b.cpu=[]; % what we store
save('EXP1.mat','EXP1'); % save down
for ii = 1:M
    % Generating data
    ii
    N = 1024; T1 = 100; Delta=T1/(N-1); % Settings
    nu = 1; ell = 7; % The Anitescu parameters in their example
    % Converting into the form of the Matern we show in equation (7.1)
    Q=[sqrt(sqrt(pi)*2*(Delta*sqrt(2*nu)/ell)^(2*nu)*(gamma(nu+.5)...
        /gamma(nu))) nu+0.5 Delta*sqrt(2*nu)/ell]; % amp, slope, damping
    tpz = maternacvs(Q,N); % autocovariance sequence
    T=transpose(chol(toeplitz(tpz))); % Cholesky factorization
    load CC.mat
    Z=CC(ii,:)'; % random numbers
    XXa=T*Z; % Matern series
    save('XXa.mat','XXa') % save it
    % De-biased Whittle Likelihood
    clear all % we clear all to accurately log all cpu times
    load('XXa.mat') % load the data
    tic; N=length(XXa)-1; nu = 1; T1 = 100; Delta=T1/(N-1); ell0=10;
    YYa=diff(XXa); % Use differenced process
    SZ=(1/N)*(abs(fft(YYa))).^2; % Periodogram
    KDPSS2=1-(0:N-1)/N;
    dampWL=fminsearchbnd(@(x)l2blur(x,nu,SZ',N,KDPSS2),Delta*sqrt(2)/ell0,0,...
        inf,optimset('GradObj','on'));
    elapsed_timeWL = toc;
    load('EXP1.mat');
    ii = length(EXP1.FD1b.cpu)+1;
    EXP1.FD1b.cpu(ii)=elapsed_timeWL;
    EXP1.FD1b.mat(ii)=dampWL;
    save('EXP1.mat','EXP1');
        % Maximum Likelihood
    clear all
    load('XXa.mat')
    tic; N=length(XXa); nu = 1; T1 = 100; Delta=T1/(N-1); ell0=10;
    dampML=fminsearchbnd(@(x)likelihoodmaternDMP(x,nu,XXa,N),Delta*sqrt(2)/ell0,0,inf,optimset('GradObj','on'));b1=toc;
    elapsed_timeML = toc;
    load('EXP1.mat');
    ii = length(EXP1.FD1b.cpu);
    EXP1.ML.cpu(ii)=elapsed_timeML;
    EXP1.ML.mat(ii)=dampML;
    save('EXP1.mat','EXP1');
    % Standard Whittle Likelihood
    clear all
    load('XXa.mat')
    tic; N=length(XXa); nu = 1; T1 = 100; Delta=T1/(N); ell0=10;
    SZ=(1/N)*(abs(fft(XXa))).^2; % Periodogram
    dampWL=fminsearchbnd(@(x)l2witt(x,nu,SZ',N),Delta*sqrt(2)/ell0,0,inf,optimset('GradObj','on'));
    elapsed_timeWL = toc;
    load('EXP1.mat');
    ii = length(EXP1.FD1b.cpu);
    EXP1.FD1.cpu(ii)=elapsed_timeWL;
    EXP1.FD1.mat(ii)=dampWL;
    save('EXP1.mat','EXP1');
        % Standard Whittle Likelihood - dpss taper
    clear all
    load('XXa.mat')
    tic; N=length(XXa); nu = 1; T1 = 100; Delta=T1/(N); ell0=10;
    filts = dpss(N,1)'; X2=XXa.*filts(1,:)'; % apply single dpss taper
    JX = fft(X2); ST = (abs(JX)).^2; % Calculate the Spectrum and multiply by Delta to be unitless
    dampWL=fminsearchbnd(@(x)l2witt(x,nu,ST',N),Delta*sqrt(2)/ell0,0,inf,optimset('GradObj','on'));
    elapsed_timeWL = toc;
    load('EXP1.mat');
    ii = length(EXP1.FD1b.cpu);
    EXP1.FD2.cpu(ii)=elapsed_timeWL;
    EXP1.FD2.mat(ii)=dampWL;
    save('EXP1.mat','EXP1');
    % De-biased Whittle Likelihood - dpss taper
    clear all
    load('XXa.mat')
    tic; N=length(XXa)-1; nu = 1; T1 = 100; Delta=T1/(N); ell0=10;
    YYa=diff(XXa);  % Use differenced process
    filts = dpss(N,1)'; X2=YYa.*filts(1,:)'; % apply single dpss taper
    JX = fft(X2); ST = (abs(JX)).^2; % Calculate the Spectrum and multiply by Delta to be unitless
    filts = dpss(N,1)'; hh2=filts(1,:)';
    KDPSS2=zeros(1,N); % taper kernel
    for kk = 0:N-1
    KDPSS2(kk+1)=sum(hh2(1:N-kk).*hh2(1+kk:N));
    end
    dampWL=fminsearchbnd(@(x)l2blur(x,nu,ST',N,KDPSS2),Delta*sqrt(2)/ell0,0,inf,optimset('Display','off','GradObj','on','MaxFunEvals',100000,'MaxIter',100000,'TolFun',1e-7,'TolX',1e-7));
    elapsed_timeWL = toc;
    load('EXP1.mat');
    ii = length(EXP1.FD1b.cpu);
    EXP1.FD2b.cpu(ii)=elapsed_timeWL;
    EXP1.FD2b.mat(ii)=dampWL;
    save('EXP1.mat','EXP1');
end
%% Table output
load('EXP1.mat')
PP=100/1023*sqrt(2)/7; % this is the true damping parameter in our coordinates
disp('bias s.d RMSE for each method:')
[100*(mean(EXP1.FD1.mat)-PP)./PP...
    100*(std(EXP1.FD1.mat)./PP)...
    100*(sqrt(mean((EXP1.FD1.mat-PP).^2))./PP)]
[100*(mean(EXP1.FD1b.mat)-PP)./PP...
    100*(std(EXP1.FD1b.mat)./PP)...
    100*(sqrt(mean((EXP1.FD1b.mat-PP).^2))./PP)]
[100*(mean(EXP1.ML.mat)-PP)./PP...
   100*(std(EXP1.ML.mat)./PP)...
   100*(sqrt(mean((EXP1.ML.mat-PP).^2))./PP)]
[100*(mean(EXP1.FD2.mat)-PP)./PP...
    100*(std(EXP1.FD2.mat)./PP)...
    100*(sqrt(mean((EXP1.FD2.mat-PP).^2))./PP)]
[100*(mean(EXP1.FD2b.mat)-PP)./PP...
    100*(std(EXP1.FD2b.mat)./PP)...
    100*(sqrt(mean((EXP1.FD2b.mat-PP).^2))./PP)]
disp('CPU times:')
[mean(EXP1.FD1.cpu) mean(EXP1.FD1b.cpu) mean(EXP1.ML.cpu) mean(EXP1.FD2.cpu) mean(EXP1.FD2b.cpu)]