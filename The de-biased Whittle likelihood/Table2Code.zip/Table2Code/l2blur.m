function [out]=l2blur(x,nu,SX,N,KDPSS2)
amp=sqrt(sqrt(pi)*2*x^(2*nu)*(gamma(nu+.5)/gamma(nu))); % amplitude
acvA=maternacvs([amp nu+.5 x],N+1); % autocovariance sequence
acv=zeros(1,N); acv(1)=2*acvA(1)-2*acvA(2);
for ii = 2:N % autocovariance of differenced process
acv(ii)=2*acvA(ii)-acvA(ii-1)-acvA(ii+1);
end
ESF2=abs(real(2*fft(acv.*KDPSS2)-acv(1))); % Blurred spectrum
out=sum(log(ESF2(2:N)))+sum(SX(2:N)./ESF2(2:N)); % Whittle likelihood