function [acv] = maternacvs(Q,N)
% Matern autocovariance as presented in Lilly (2016) 
acv = zeros(1,N); % acvs from lag 0 to N-1 (not 1 to N)
acv(1)=beta(0.5,Q(2)-0.5)*Q(1)^2/(2*pi*Q(3)^(2*Q(2)-1)); % variance
acv(2:N)=Q(1)^2*(Q(3)*(1:N-1)).^(Q(2)-.5).*besselk(Q(2)-.5,Q(3)*(1:N-1))...
    ./(sqrt(pi)*2^(Q(2)-.5).*(Q(3))^(2*Q(2)-1)*gamma(Q(2)));