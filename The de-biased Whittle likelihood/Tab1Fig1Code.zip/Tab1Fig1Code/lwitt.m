function [out]=lwitt(x,SX,N,omega,Debias,HKK)
% This function computes either l_W or l_D in the paper for X_t
if Debias == 0 % Standard Whittle
    omega(N-floor(N/2)+1:N)=omega(N-floor(N/2)+1:N)-2*pi; % frequencies
    ESF3=x(1)^2./(omega.^2+x(3)^2).^abs(x(2)); % spectrum
    out=sum(log(ESF3))+sum(SX./ESF3); % summation
elseif Debias > 0 % De-biased Whittle
    acv(1)=beta(0.5,x(2)-0.5)*x(1)^2/(2*pi*x(3)^(2*x(2)-1)); % autocov
    FF(2:N)=x(1)^2.*(x(3)*(1:N-1)).^(x(2)-.5).*besselk(x(2)-.5,x(3)*(1:N-1));
    acv(2:N)=FF(2:N)./(sqrt(pi)*2^(x(2)-.5).*x(3)^(2*x(2)-1)*gamma(x(2)));
    if Debias == 1
        ESF2=abs(real(2*fft(acv.*(1-(0:N-1)/N))-acv(1))); %blurred spectrum
        out=sum(log(ESF2))+sum(SX./ESF2); % summation
    else % tapered De-biased Whittle
        ESF2=abs(real(2*fft(acv.*HKK)-acv(1))); % blurred spectrum
        out=sum(log(ESF2))+sum(SX./ESF2); % summation
    end
end