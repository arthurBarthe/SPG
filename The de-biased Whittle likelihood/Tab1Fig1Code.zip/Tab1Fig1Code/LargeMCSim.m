%% Preliminaries
rng(1); % This is the random number seed we used
M=10000; % Number of replicates (can set this to something smaller than 10000)
N=1000; % Length of time series
N1=N-1; % Length of differenced time series
BB = randn(M,N); % random numbers
SLOPE = 0.6:0.1:2.5; % Slope parameters
damp = .2; % Damping parameter
Tab1=[]; % This is where we save our parameters
omega=0:2*pi/N:2*pi*(1-1/N); % Discrete Fourier Frequencies
omega1=0:2*pi/N1:2*pi*(1-1/N1); % Fourier Frequencies (differenced process)
fLSS2=ones(2,floor(3*N/8)-floor(N/8)+1); % for initialization
fLSS2(2,:)=log(omega(floor(N/8):floor(3*N/8))); % initialization freq.
filts=dpss(N,4)'; hh1=filts(1,:)'; % dpss taper of bandwith 4
HHK=zeros(1,N); % precomputation of h_t h_{t+\tau},described on page 16
for mm=0:N-1
    HHK(mm+1)=sum(hh1(1:N-mm).*hh1(1+mm:N));
end
% options for minimization (used later)
options=optimset('GradObj','on','MaxFunEvals',10000,'MaxIter',10000);
LL=[0 0.501 pi/N]; UU=[inf 4 pi/2]; % Parameter bounds we search over
for j = 1:M % begin the loop over M
    j
for jj = 1:20 % begin the loop over slope parameters
    alpha = SLOPE(jj); % slope parameter
    Q=[1 alpha damp]; % Matern parameters
    tpz = zeros(1,N); % Initializing the autocovariance sequence
    % Matern autocovariance (see Lilly et al (2016))
    tpz(1)=beta(0.5,Q(2)-0.5)*Q(1)^2/(2*pi*Q(3)^(2*Q(2)-1));
    FF(2:N)=Q(1)^2.*(Q(3)*(1:N-1)).^(Q(2)-.5).*besselk(Q(2)-.5,Q(3)*(1:N-1));
    tpz(2:N)=FF(2:N)./(sqrt(pi)*2^(Q(2)-.5).*(Q(3))^(2*Q(2)-1)*gamma(Q(2)));
    % Generate data by Cholesky Factorization
    T=transpose(chol(toeplitz(tpz)));
    Z=BB(j,1:N)'; X=T*Z; % multiply by random Gaussian to generate series
    Y = diff(X); % and here is the differenced time series
    %% COMPUTING PERIODOGRAMS
    Xh = X.*hh1; % tapered sequence
    JTh = fft(Xh); STh = (abs(JTh)).^2; % Tapered
    SX=(1/N)*(abs(fft(X))).^2; % Regular
    SX1=(1/N1)*(abs(fft(Y))).^2; % Differenced
    %% Initial values for optimzation by least squares (between w/4-3w/4)
    b=lscov(fLSS2',log(STh(floor(N/8):floor(3*N/8))));
    xb=zeros(1,3); xb(1)=exp(b(1)/2+0.5772/2); xb(2)=max(0.6,-b(2)/2);
    xb(3)=100*pi/N; % set c as 100 times the Rayleigh frequency
    %% Whittle Likelihood optimizations using fminsearchbnd
    %% Standard Periodogram
    x1=fminsearchbnd(@(x) lwitt(x,SX',N,omega,0,HHK),xb,LL,UU,options);
    Tab1.FD1.mat(jj,j,1:3)=x1;
    %% De-biased Periodogram
    x2=fminsearchbnd(@(x) lwitt(x,SX',N,omega,1,HHK),xb,LL,UU,options);
    Tab1.FD1b.mat(jj,j,1:3)=x2;
    %% Standard Periodogram Differenced Data
    x3=fminsearchbnd(@(x) lwittD(x,SX1',N1,omega1,0),xb,LL,UU,options);
    Tab1.FD2.mat(jj,j,1:3)=x3;
    %% De-biased Periodogram Differenced Data
    x4=fminsearchbnd(@(x) lwittD(x,SX1',N1,omega1,1),xb,LL,UU,options);
    Tab1.FD2b.mat(jj,j,1:3)=x4;
    %% Standard Tapered
    x5=fminsearchbnd(@(x) lwitt(x,STh',N,omega,0,HHK),xb,LL,UU,options);
    Tab1.FD3.mat(jj,j,1:3)=x5;
    %% De-biased Tapered NoDiff
    x6=fminsearchbnd(@(x) lwitt(x,STh',N,omega,2,HHK),xb,LL,UU,options);
    Tab1.FD3b.mat(jj,j,1:3)=x6;
end
end