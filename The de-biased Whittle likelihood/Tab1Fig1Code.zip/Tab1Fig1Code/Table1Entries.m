True = ones(3,20);
True(2,:) = 0.6:0.1:2.5;
True(3,:) = 0.2;
AA=[];BB=[];CC=[];DD=[];EE=[];FF=[];
for pp = 1:3
    AA(pp,:)=abs(mean(Tab1.FD1.mat(1:20,:,pp),2)-True(pp,1:20)')./True(pp,1:20)';
end
for pp = 1:3
    BB(pp,:)=abs(mean(Tab1.FD1b.mat(1:20,:,pp),2)-True(pp,1:20)')./True(pp,1:20)';
end
for pp = 1:3
    CC(pp,:)=abs(mean(Tab1.FD3.mat(1:20,:,pp),2)-True(pp,1:20)')./True(pp,1:20)';
end
for pp = 1:3
    DD(pp,:)=abs(mean(Tab1.FD3b.mat(1:20,:,pp),2)-True(pp,1:20)')./True(pp,1:20)';
end
for pp = 1:3
    EE(pp,:)=abs(mean(Tab1.FD2.mat(1:20,:,pp),2)-True(pp,1:20)')./True(pp,1:20)';
end
for pp = 1:3
    FF(pp,:)=abs(mean(Tab1.FD2b.mat(1:20,:,pp),2)-True(pp,1:20)')./True(pp,1:20)';
end
%%
disp('Biases:')
[mean(mean(AA)) mean(mean(BB)) mean(mean(CC)) mean(mean(DD)) mean(mean(EE)) mean(mean(FF))]
%%
for pp = 1:3
    AA(pp,:)=abs(std(Tab1.FD1.mat(1:20,:,pp)'))./True(pp,1:20);
end
for pp = 1:3
    BB(pp,:)=abs(std(Tab1.FD1b.mat(1:20,:,pp)'))./True(pp,1:20);
end
for pp = 1:3
    CC(pp,:)=abs(std(Tab1.FD3.mat(1:20,:,pp)'))./True(pp,1:20);
end
for pp = 1:3
    DD(pp,:)=abs(std(Tab1.FD3b.mat(1:20,:,pp)'))./True(pp,1:20);
end
for pp = 1:3
    EE(pp,:)=abs(std(Tab1.FD2.mat(1:20,:,pp)'))./True(pp,1:20);
end
for pp = 1:3
    FF(pp,:)=abs(std(Tab1.FD2b.mat(1:20,:,pp)'))./True(pp,1:20);
end
%%
disp('Standard Deviations:')
[mean(mean(AA)) mean(mean(BB)) mean(mean(CC)) mean(mean(DD)) mean(mean(EE)) mean(mean(FF))]
%%
for pp = 1:3
    AA(pp,:)=sqrt(mean((Tab1.FD1.mat(:,:,pp)-True(pp,:)'*ones(1,M)).^2,2))./True(pp,:)';
end
for pp = 1:3
    BB(pp,:)=sqrt(mean((Tab1.FD1b.mat(:,:,pp)-True(pp,:)'*ones(1,M)).^2,2))./True(pp,:)';
end
for pp = 1:3
    CC(pp,:)=sqrt(mean((Tab1.FD3.mat(:,:,pp)-True(pp,:)'*ones(1,M)).^2,2))./True(pp,:)';
end
for pp = 1:3
    DD(pp,:)=sqrt(mean((Tab1.FD3b.mat(:,:,pp)-True(pp,:)'*ones(1,M)).^2,2))./True(pp,:)';
end
for pp = 1:3
    EE(pp,:)=sqrt(mean((Tab1.FD2.mat(:,:,pp)-True(pp,:)'*ones(1,M)).^2,2))./True(pp,:)';
end
for pp = 1:3
    FF(pp,:)=sqrt(mean((Tab1.FD2b.mat(:,:,pp)-True(pp,:)'*ones(1,M)).^2,2))./True(pp,:)';
end
%%
disp('RMSE:')
[mean(mean(AA)) mean(mean(BB)) mean(mean(CC)) mean(mean(DD)) mean(mean(EE)) mean(mean(FF))]