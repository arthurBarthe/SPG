function [out]=lwittD(x,SX,N,omega,Debias)
% This function computes l_W or l_D for differenced process Y_t
if Debias == 0 % Standard Whittle
    omega(N-floor(N/2)+1:N)=omega(N-floor(N/2)+1:N)-2*pi;
    ESF3=(4*sin(omega/2).^2).*x(1)^2./(omega.^2+x(3)^2).^x(2); % spectrum
    out=sum(log(ESF3(2:N)))+sum(SX(2:N)./ESF3(2:N)); % summation
else % De-biased Whittle
    acvA(1)=beta(0.5,x(2)-0.5)*x(1)^2/(2*pi*x(3)^(2*x(2)-1)); % autocov
    FF(2:N+1)=x(1)^2.*(x(3)*(1:N)).^(x(2)-.5).*besselk(x(2)-.5,x(3)*(1:N));
    acvA(2:N+1)=FF(2:N+1)./(pi^.5*2^(x(2)-.5).*x(3)^(2*x(2)-1)*gamma(x(2)));
    acv=zeros(1,N); acv(1)=2*acvA(1)-2*acvA(2);
    for ii = 2:N % autocovariance of differenced process
        acv(ii)=2*acvA(ii)-acvA(ii-1)-acvA(ii+1);
    end
    ESF2=abs(real(2*fft(acv.*(1-(0:N-1)/N))-acv(1))); % blurred spectrum
    out=sum(log(ESF2(2:N)))+sum(SX(2:N)./ESF2(2:N)); % summation
end