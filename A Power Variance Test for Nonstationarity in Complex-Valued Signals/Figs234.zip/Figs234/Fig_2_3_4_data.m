clear all

nRep=10000;
n=1000;
rng('default');

%%generate data for fig 3
pVal=nan(nRep,1);
obsPowerVar=nan(nRep,1);
for iRep=1:nRep

    disp(['Jump process: ',num2str(iRep),'/',num2str(nRep)])

    z=randn(n,1)/sqrt(2)+sqrt(-1)*randn(n,1)/sqrt(2);
    z(1:floor(n/2))=z(1:floor(n/2))+1;
    z((floor(n/2)+1):n)=z((floor(n/2)+1):n)+3;
    [obsPowerVar(iRep),~,permPowerVar,~]=SPVNT(z);
    pVal(iRep)=sum(permPowerVar>obsPowerVar(iRep))/length(permPowerVar);
    
end
save('Fig3data.mat','n','nRep','obsPowerVar','pVal')

%%generate data for fig 4
w1=10;
a1=1;
t=[1:n]'/n;
z1=a1*exp(sqrt(-1)*w1*t);
obsPowerVar=nan(nRep,1);
pVal=nan(nRep,1);
for iRep=1:nRep

    disp(['Cyclo-stationary process: ',num2str(iRep),'/',num2str(nRep)])

    z0=(randn(n,1)+sqrt(-1)*randn(n,1))/sqrt(2);
    z=z0+z1;
    [obsPowerVar(iRep),~,permPowerVar,~]=SPVNT(z);
    pVal(iRep)=sum(permPowerVar<obsPowerVar(iRep))/length(permPowerVar);
    
end
save('Fig4data.mat','n','nRep','obsPowerVar','pVal')

%%generate data for fig 2
pVal=nan(nRep,1);
obsPowerVar=nan(nRep,1);
for iRep=1:nRep

    disp(['AR1 process: ',num2str(iRep),'/',num2str(nRep)])

    ARdata=(simulate(arima('Constant',0,'AR',{0.9},'Variance',.1),n)+sqrt(-1)*simulate(arima('Constant',0,'AR',{0.9},'Variance',.1),n))/sqrt(2);
    [obsPowerVar(iRep),~,permPowerVar,~]=SPVNT(ARdata);
    pVal(iRep)=sum(permPowerVar>obsPowerVar(iRep))/length(permPowerVar);
    
end
pVal(pVal>0.5)=1-pVal(pVal>0.5);
pVal=2*pVal;
save('Fig2data.mat','n','nRep','obsPowerVar','pVal')
