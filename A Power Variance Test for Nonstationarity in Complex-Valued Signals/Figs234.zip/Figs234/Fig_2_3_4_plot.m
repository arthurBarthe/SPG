clear all

mar=[0.27 0.05 0.03 0.18];%subplot margins, moving clockwise from left
fntSz=14;
nHist=20;
xbins=linspace(0,1,nHist+1);
xbins=xbins(2:end)-1/(2*nHist);

filenames={'Fig2','Fig3','Fig4'};
nF=length(filenames);

hf=nan(nF,1);
ha=nan(nF,1);

for iF=1:nF

    filename=filenames{iF};
    load([filename,'data.mat'])

    hf(iF)=figure(1);
    clf(hf(iF))
    set(hf(iF),'paperposition',[0 0 3 3]);
    set(hf(iF), 'PaperSize', [3 3]);
    ha(iF)=axes('units','normalized','position',[mar(1),mar(4),(1-mar(1)-mar(3)),(1-mar(2)-mar(4))]);

    hist(pVal,xbins)
    xlim([0,1])
    ylim([0,max(hist(pVal,xbins))])
    h=findobj(hf(iF),'Type','patch');
    h.FaceColor = [0.5 0.5 0.5];
    hold on
    plot([0.05,0.05],[0,max(hist(pVal,xbins))],'color','r','linewidth',2)
    hold off
    
    xlabel('{\itp}-val')
    ylabel('Freq')
    set(gca,'fontsize',fntSz,'FontName','Times New Roman')
    
    print('-dpdf','-r1200',[filename,'.pdf']);
    close(hf(iF))

    disp([filename,': ',num2str(100*sum(pVal<0.05)/length(pVal)),'% significant'])
    
end
