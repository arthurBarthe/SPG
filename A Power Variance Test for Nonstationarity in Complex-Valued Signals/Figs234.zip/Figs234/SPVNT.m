function [obsPowerVar,predMu,permPowerVar,pVal]=SPVNT(z)

        %% SPVNT - Sample Power Variance Non-stationarity Test
        %%
        %%      Input is the complex-valued time-series z
        %%     Output is [obsPowerVar,predMu,predSigma2,zStat,pVal,permPowerVar]
        %%
        %%  obsPowerVar = Sample power variance of z.
        %%       predMu = Predicted mean of the sample power variance of a stationary
        %%                distribution with the same amplitude spectrum as z.
        %%
        %% permPowerVar = Empirical distribution of the sample power variance
        %%                under a null hypothesis of stationarity, generated 
        %%                by randomly sampling the phases of a permuted z from 
        %%                a uniform distribution, whilst keeping the amplitude 
        %%                spectrum of the original z. (Will not be calculated
        %%                unless requested).
        %%         pVal = Upper-tailed test p-value based on phase-resampled
        %%                empirical null distribution (Will not be calculated 
        %%                unless requested).

        if(size(z,2)>size(z,1))
            z=transpose(z);
        end
        if(size(z,2)>1)
            error('SPVNT requires vector input')
        end
        
        n=length(z);
        obsPowerVar=var(abs(z).^2);

        FFTvec=fft(z);
        Z=abs(FFTvec);
        sZ2=sum(Z.^2);
        sZ4=sum(Z.^4);
        
        predMu=(sZ2^2-sZ4)/n^4;

        if(nargout>2)
            nB=1000;%number of phase-resampled null power variance permutations
            randAng=rand(nB,n)*2*pi-pi;
            zRand=ifft((ones(nB,1)*Z').*exp(sqrt(-1)*randAng),[],2);
            zRand2=abs(zRand).^2;
            permPowerVar=var(zRand2,0,2);
            permPowerVar=sort(permPowerVar);
            pVal=sum(permPowerVar>obsPowerVar)/nB;
        end      

end