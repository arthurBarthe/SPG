clear all

fntSz=20;
rng('default');
load('cvf.mat')
z=cvf(:,1);
[obsPowerVarTemp,predMuTemp,permPowerVar,~]=SPVNT(z);
pTemp=2*min([sum(permPowerVar>obsPowerVarTemp),sum(permPowerVar<obsPowerVarTemp)])/length(permPowerVar);

%%Figure 1
mar=[0.18 0.02 0.05 0.13];%subplot margins, moving clockwise from left
hf=figure(1);
clf(hf)
set(hf,'paperposition',[0 0 6 5.6]);
set(hf, 'PaperSize', [6 5.6]);
ha=axes('units','normalized','position',[mar(1),mar(4),(1-mar(1)-mar(3)),(1-mar(2)-mar(4))]);
plot([0;cumsum(z)],'linewidth',2)
axis equal
xlabel('West - East (kilometers)')
ylabel('South - North (kilometers)')
set(gca,'fontsize',fntSz,'FontName','Times New Roman')
print('-dpdf','-r1200','Fig1a.pdf');
close(hf)

%%Figure 5
mar=[0.16 0.12 0.05 0.2];%subplot margins, moving clockwise from left
hf=figure(1);
clf(hf)
set(hf,'paperposition',[0 0 6 4]);
set(hf, 'PaperSize', [6 4]);
ha=axes('units','normalized','position',[mar(1),mar(4),(1-mar(1)-mar(3)),(1-mar(2)-mar(4))]);
plot((1:length(z))-1,real(z),'color','k','linewidth',2)   
xlabel('Time (days)')
ylabel('Real part of velocity (km/day)')
set(gca,'fontsize',fntSz,'FontName','Times New Roman')
print('-dpdf','-r1200','Fig5a.pdf');
close(hf)

%%Figure 6
mar=[0.13 0.08 0.05 0.16];%subplot margins, moving clockwise from left
hf=figure(1);
clf(hf)
set(hf,'paperposition',[0 0 6 5]);
set(hf, 'PaperSize', [6 5]);
ha=axes('units','normalized','position',[mar(1),mar(4),(1-mar(1)-mar(3)),(1-mar(2)-mar(4))]);
colours=get(gca,'colororder');
hold on  
[densObs,pvi]=ksdensity(permPowerVar);
plot(obsPowerVarTemp*ones(1,2),[0,max(densObs)],'color',colours(3,:),'linewidth',3)
plot(pvi,densObs,'-','color',colours(1,:),'linewidth',3)
plot(predMuTemp*ones(1,2),[0,max(densObs)],'color',colours(2,:),'linewidth',3)
xlim([min([obsPowerVarTemp,min(pvi)]),max([obsPowerVarTemp,max(pvi)])]+0.05*[-1,1]*range(pvi))
ylim([0,max(densObs)])
xlabel('Sample power variance')
ylabel('Density')
title(['{\itp} = ',num2str(pTemp)])
set(gca,'fontsize',fntSz,'FontName','Times New Roman')
% hl=legend({'Observed {\itV}','Null {\itV} distr.','Predicted \mu_{\itV}'},'Location','northeast');
box on
hold off
print('-dpdf','-r1200','Fig6a.pdf');
close(hf)
