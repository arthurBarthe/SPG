Fig1TopRight=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 500.0]);
load drifterbetty2.mat
XX = drifterbetty.lon+1i.*drifterbetty.lat; % position series
Z=(XX(2801:3281)); plot(Z,'k');
xlabel('Longitude'); ylabel('Latitude');
ax = gca; title('(b)');
ax.XTick = [-70,-69.5,-69,-68.5];
ax.YTick = [35.5,36];
%xlim([-70.5 -68]);
axis('tight');
ylim([35.25 36.25]);
exportfig(Fig1TopRight, 'Fig1TopRight.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);
%%
ZZ = drifterbetty.cv/100; Z1 = ZZ(2801:3281); tt = 0:1/12:40; % velocity series
Fig1BottomLeft=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 500.0]);
plot(tt,real(Z1),'k'); hold on; plot(tt,imag(Z1),'color',[.5 .5 .5]); % plotting the real and imaginary time series
legend('Lon','Lat'); xlabel('Day'); ylabel('m/s'); xlim([0 40]);
ax = gca; title('(c)');
ax.XTick = [0,10,20,30,40];
ax.YTick = [-1,0,1];
exportfig(Fig1BottomLeft, 'Fig1BottomLeft.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);
%%
Fig1BottomRight=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 500.0]);

BW=3;
AAA=dpss(481,BW);
SPEC=(abs(fft(AAA.*((Z1(1:481)-mean(Z1(1:481)))*ones(1,2*BW))))).^2;


%SPEC=(2/481)*abs(fft(Z1(1:481)-mean(Z1(1:481)))).^2; 
SPECP = SPEC(2:241); SPECM = SPEC(481:-1:242); % rotary spectra
omega = 2*pi/481:2*pi/481:pi; % discrete Fourier frequencies
plot(omega,10*log10(SPECP),'k'); hold on; plot(omega,10*log10(SPECM),'color',[.5 .5 .5]);
xlim([0 pi]); ylim([-50 20]); legend('+ve: S_{++}(\omega)','-ve: S_{--}(\omega)'); xlabel('\omega (cycles per day)'); ylabel('dB');
ax = gca; title('(d)');
ax.XTick = [0,pi/3,2*pi/3,pi];
ax.XTickLabel = {'0','2','4','6'}
ax.YTick = [-40,-20,0];
exportfig(Fig1BottomRight, 'Fig1BottomRight.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);