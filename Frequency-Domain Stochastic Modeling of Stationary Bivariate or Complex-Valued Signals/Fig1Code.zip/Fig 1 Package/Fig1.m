Fig1TopRight=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 500.0]);
load drifterbetty2.mat
XX = drifterbetty.lon+1i.*drifterbetty.lat; % position series
Z=(XX(2801:4600)); X=(XX(2801:3280)); % This is the time series and the 40 day segment
plot(X,'b','linewidth',1.5,'linestyle','-.');
hold on; plot(Z,'color',[.5 .5 .5]);
legend('Day 1 to 40','Day 40 to 150');
hold on; plot(X,'b','linewidth',1.5,'linestyle','-.');
xlabel('Longitude'); ylabel('Latitude');
ax = gca;
ax.XTick = [-70,-69,-68,-67,-66];
ax.YTick = [34,35,36,37]; axis equal
xlim([-71 -65]); ylim([33.5 37.5]);
exportfig(Fig1TopRight, 'Fig1TopRight.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);
%%
ZZ = drifterbetty.cv/100; Z1 = ZZ(2801:4600); tt = 0:1/12:150-1/12; % velocity series
Fig1BottomLeft=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 500.0]);
plot(tt,real(Z1),'r'); hold on; plot(tt,imag(Z1),'b','linestyle','-.','linewidth',1.5); % plotting the real and imaginary time series
legend('Lon','Lat'); xlabel('Day'); ylabel('m/s'); xlim([0 150]);
ax = gca;
ax.XTick = [0,50,100,150];
ax.YTick = [-1,0,1];
exportfig(Fig1BottomLeft, 'Fig1BottomLeft.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);
%%
Fig1BottomRight=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 500.0]);
SPEC=(2/481)*abs(fft(Z1(1:481)-mean(Z1(1:481)))).^2; SPECP = SPEC(2:241); SPECM = SPEC(481:-1:242); % rotary spectra
omega = 2*pi/481:2*pi/481:pi; % discrete Fourier frequencies
plot(omega,10*log10(SPECP),'b'); hold on; plot(omega,10*log10(SPECM),'r','linestyle','-.','linewidth',1.5);
xlim([0 pi]); legend('+ve: S_{++}(\omega)','-ve: S_{--}(\omega)'); xlabel('\omega (cycles per day)'); ylabel('dB');
ax = gca;
ax.XTick = [0,pi/3,2*pi/3,pi];
ax.XTickLabel = {'0','2','4','6'}
ax.YTick = [-40,-20,0,20];
exportfig(Fig1BottomRight, 'Fig1BottomRight.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);