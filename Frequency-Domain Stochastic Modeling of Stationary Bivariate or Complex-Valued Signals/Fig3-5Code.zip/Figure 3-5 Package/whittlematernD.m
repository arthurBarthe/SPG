function [out]=whittlematernD(x,SZ,RZ,N,Delta)

omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi;
ESF3 = x(1)^2./(omega.^2+x(3)^2).^x(2); ESF3=ESF3(floor(N/2)+2:floor(14*N/20));
ESF5 = max(0,1-abs(x(4).*omega)).*x(1)^2./(omega.^2+x(3)^2).^x(2); ESF5=ESF5(floor(N/2)+2:floor(14*N/20));

SPP = SZ(floor(N/2)+2:floor(14*N/20));
SMM = SZ(floor(N/2):-1:floor(N/2)-length(SPP)+1);
SPM = RZ; SPM = SPM(floor(N/2)+2:floor(14*N/20));

out=sum(log(ESF3.^2-ESF5.^2))+sum((ESF3.*SPP-2*ESF5.*real(SPM)+ESF3.*SMM)./(ESF3.^2-ESF5.^2));