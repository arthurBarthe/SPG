tpz = maternacvs([10 5.559 0.6354],N,1); % autocovariance sequence of Matern with parameters similar to those in Fig 4.
T=transpose(chol(toeplitz(tpz))); M=10000;
for ii = 1:M
    ii
Z=randn(N,1)+1i.*randn(N,1); X=T*Z;
BW=3;
AAA=dpss(N,BW);
SZT=(abs(fft(AAA.*(X*ones(1,2*BW))))).^2; SZT=mean(fftshift(SZT),2);
SZCT=fft(AAA.*(X*ones(1,2*BW))).*conj(fft(AAA.*(conj(X)*ones(1,2*BW)))); SZCT=mean(fftshift(SZCT),2);
%% Starting values using least squares on one side of spectrum
b=lscov(fLSS2',log(SZT(floor(N/4):floor(3*N/8)))); % least squares against log of periodogram
xb=zeros(1,4); xb(1)=exp(b(1)/2); xb(2)=max(0.51,-b(2)/2); xb(3)=0.1*2*pi; % then, we solve for \phi and \nu and then set \alpha as 0.1 cycles per day
ST=real(SZCT); ST = ST(floor(N/2)+1:N); [a,b] = min(ST>0); xb(4)=N/(2*pi*b); % c is set by the first zero crossing of the rotary coherency
%% Whittle likelihood (First optimisation is to find 3 Matern parameters, second is to find the anisotropy parameter)
xN2=fminsearchbnd(@(x) whittlematernD(x,SZT',SZCT',N,Delta),[xb(1:3) 2*pi/N],[0,0.5,2*pi/N N/(2*pi)],[inf 8 inf N/(2*pi)],options); % isotropic likelihood
xN=fminsearchbnd(@(x) whittlematernD(x,SZT',SZCT',N,Delta),xb,[0,0.5,2*pi/N 0],[inf 8 inf N/(2*pi)],options); % anisotropic likelihood
LRTSM(ii)=-whittlematernD(xN,SZT',SZCT',N,Delta)+whittlematernD(xN2,SZT',SZCT',N,Delta);
end
CIB=sort(2*LRTSM); CIB(0.95*M) % bootstrap 95% confidence interval