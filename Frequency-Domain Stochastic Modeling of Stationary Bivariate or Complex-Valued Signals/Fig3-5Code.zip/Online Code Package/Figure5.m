%% Preliminaries
load QGBetaPlaneTurbulenceFloats_experiment_04.mat
Delta=1; N=1001;
options=optimset('GradObj','on','MaxFunEvals',10000,'MaxIter',10000,'TolFun',1e-6,'TolX',1e-6); % some options for fminsearch, Gradient method used for likelihood
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % fourier coefficients, correct for odd or even N
fLSS2=ones(2,1+floor(3*N/8)-floor(N/4)); fLSS2(2,:)=log(abs(omega(floor(N/4):floor(3*N/8)))); % log of frquencies used in least squares for starting estimates
LRTS=zeros(2,256); AnisoTime=zeros(1,256);
PARAM1=zeros(3,256); PARAM2=zeros(3,256);
%LRTS is the likelihood ratio test statistic
%AnisoTime is the anisotropy timescale 2\pi c\Delta
for ii =1:256
    [1 ii]
X = cv(:,ii)*60*60*24; % this is the trajectory
X=X-mean(X);
BW=3;
AAA=dpss(N,BW);
SZT=(abs(fft(AAA.*(X*ones(1,2*BW))))).^2; SZT=mean(fftshift(SZT),2);
SZCT=fft(AAA.*(X*ones(1,2*BW))).*conj(fft(AAA.*(conj(X)*ones(1,2*BW)))); SZCT=mean(fftshift(SZCT),2);
%% Starting values using least squares on one side of spectrum
b=lscov(fLSS2',log(SZT(floor(N/4):floor(3*N/8)))); % least squares against log of periodogram
xb=zeros(1,4); xb(1)=exp(b(1)/2); xb(2)=max(0.51,-b(2)/2); xb(3)=0.1*2*pi; % then, we solve for \phi and \nu and then set \alpha as 0.1 cycles per day
ST=real(SZCT); ST = ST(floor(N/2)+1:N); [a,b] = min(ST>0); xb(4)=N/(2*pi*b); % c is set by the first zero crossing of the rotary coherency
%% Whittle likelihood (First optimisation is to find 3 Matern parameters, second is to find the anisotropy parameter)
xN2=fminsearchbnd(@(x) whittlematernD(x,SZT',SZCT',N,Delta),[xb(1:3) 2*pi/N],[0,0.5,2*pi/N N/(2*pi)],[inf 8 inf N/(2*pi)],options); % isotropic likelihood
xN=fminsearchbnd(@(x) whittlematernD(x,SZT',SZCT',N,Delta),xb,[0,0.5,2*pi/N 0],[inf 8 inf N/(2*pi)],options); % anisotropic likelihood
LRTS(1,ii)=-whittlematernD(xN,SZT',SZCT',N,Delta)+whittlematernD(xN2,SZT',SZCT',N,Delta);
PARAM1(:,ii)=xN(1:3);
AnisoTime(ii)=2*pi*xN(4)*Delta;
end
%%
load QGBetaPlaneTurbulenceFloats_experiment_05.mat % the isotropic data
for ii =1:256
    [2 ii]
X = cv(:,ii)*60*60*24; % this is the trajectory
X=X-mean(X);
BW=3;
AAA=dpss(N,BW);
SZT=(abs(fft(AAA.*(X*ones(1,2*BW))))).^2; SZT=mean(fftshift(SZT),2);
SZCT=fft(AAA.*(X*ones(1,2*BW))).*conj(fft(AAA.*(conj(X)*ones(1,2*BW)))); SZCT=mean(fftshift(SZCT),2);
%% Starting values using least squares on one side of spectrum
b=lscov(fLSS2',log(SZT(floor(N/4):floor(3*N/8)))); % least squares against log of periodogram
xb=zeros(1,4); xb(1)=exp(b(1)/2); xb(2)=max(0.51,-b(2)/2); xb(3)=0.1*2*pi; % then, we solve for \phi and \nu and then set \alpha as 0.1 cycles per day
ST=real(SZCT); ST = ST(floor(N/2)+1:N); [a,b] = min(ST>0); xb(4)=N/(2*pi*b); % c is set by the first zero crossing of the rotary coherency
%% Whittle likelihood (First optimisation is to find 3 Matern parameters, second is to find the anisotropy parameter)
xN2=fminsearchbnd(@(x) whittlematernD(x,SZT',SZCT',N,Delta),[xb(1:3) 2*pi/N],[0,0.5,2*pi/N N/(2*pi)],[inf 8 inf N/(2*pi)],options); % isotropic likelihood
xN=fminsearchbnd(@(x) whittlematernD(x,SZT',SZCT',N,Delta),xb,[0,0.5,2*pi/N 0],[inf 8 inf N/(2*pi)],options); % anisotropic likelihood
LRTS(2,ii)=-whittlematernD(xN,SZT',SZCT',N,Delta)+whittlematernD(xN2,SZT',SZCT',N,Delta);
PARAM2(:,ii)=xN2(1:3);
end
%%
Fig5L=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 400.0]); aa=histogram(max(0,2*LRTS(2,:)),16,'FaceColor',[0.5 0.75 1]);
hold on; histogram(2*LRTS(1,:),36,'FaceColor',[0 .1 .4])
xlim([0 110])
ylim([0 35])
CIB=1.4724; % Bootstrap confidence limit (run btstrap.m to see how this was obtained)
hold on; line([CIB CIB],[0 40],'color','r','linewidth',2)
xlabel('W'); ylabel('no. of signals'); title('(a)');
legend('Isotropic Data','Anisotropic Data','95% Confidence')
ax = gca;
ax.XTick = [0,20,40,60,80,100,120];
ax.YTick = [0,10,20,30];
exportfig(Fig5L, 'Fig5a.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);
%%
Fig5R=figure('PaperUnits','inches','Position',[0.25 2.5 800.0 400.0]);
histogram(AnisoTime,50,'FaceColor',[0 .1 .4]);
xlabel('2\pic (Days)')
hold on; line([23 23],[0 24],'color','b','linewidth',1.5)
hold on; line([median(AnisoTime) median(AnisoTime)],[0 24],'color','r','linestyle','--','linewidth',1.5)
legend('Estimates','Anisotropy Timescale','Median of Estimates')
xlim([10 50]); ylim([0 24]); ylabel('no. of signals'); title('(b)');
ax = gca;
ax.XTick = [10,20,30,40,50];
ax.YTick = [0,10,20];
exportfig(Fig5R, 'Fig5b.eps', 'width', 8, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);
%%
display(['Median anisotropy time is = ',num2str(median(AnisoTime))]);
display(['Number of false positives = ',num2str(sum(2*LRTS(2,:)>CIB))]);
display(['Number of isotropic data entries in first column = ',num2str(aa.Values(1))]);