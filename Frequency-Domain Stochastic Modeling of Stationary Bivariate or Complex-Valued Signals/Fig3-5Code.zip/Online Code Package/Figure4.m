%% Preliminaries
load QGBetaPlaneTurbulenceFloats_experiment_04.mat % the data
Delta=1; N=1001;
options=optimset('GradObj','on','MaxFunEvals',10000,'MaxIter',10000,'TolFun',1e-6,'TolX',1e-6); % some options for fminsearch, Gradient method used for likelihood
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % fourier coefficients, correct for odd or even N
fLSS2=ones(2,1+floor(3*N/8)-floor(N/4)); fLSS2(2,:)=log(abs(omega(floor(N/4):floor(3*N/8)))); % log of frquencies used in least squares for starting estimates
X = cv(:,138)*60*60*24; % this is the trajectory we use for Figure 4
X=X-mean(X); % remove mean
BW=5; % taper bandwidth (note typo on paper, bandwidth is 5 not 3)
AAA=dpss(N,BW); % dpss taper
SZT=(abs(fft(AAA.*(X*ones(1,2*BW))))).^2; SZT=mean(fftshift(SZT),2); % Tapered spectral estimate of Z
SXT=(abs(fft(AAA.*(real(X)*ones(1,2*BW))))).^2; SXT=mean(fftshift(SXT),2); % Tapered spectral estimate of X
SYT=(abs(fft(AAA.*(imag(X)*ones(1,2*BW))))).^2; SYT=mean(fftshift(SYT),2); % Tapered spectral estimate of Y
SZCT=fft(AAA.*(X*ones(1,2*BW))).*conj(fft(AAA.*(conj(X)*ones(1,2*BW)))); SZCT=mean(fftshift(SZCT),2); % Tapered complementary spectral estimate of Z
JZ = sqrt(Delta/N)*fft(X); JZ=fftshift(JZ);
SZ = abs(JZ).^2;
RZ = JZ.*JZ(N:-1:1);
%% Starting values using least squares on one side of spectrum
b=lscov(fLSS2',log(SZT(floor(N/4):floor(3*N/8)))); % least squares against log of periodogram
xb=zeros(1,4); xb(1)=exp(b(1)/2); xb(2)=max(0.51,-b(2)/2); xb(3)=0.1*2*pi; % then, we solve for \phi and \nu and then set \alpha as 0.1 cycles per day
ST=real(SZCT); ST = ST(floor(N/2)+1:N); [a,b] = min(ST>0); xb(4)=N/(2*pi*b); % c is set by the first zero crossing of the rotary coherency
%% Whittle likelihood (First optimisation is to find 3 Matern parameters, second is to find the anisotropy parameter)
xN=fminsearchbnd(@(x) whittlematernD(x,SZT',SZCT',N,Delta),xb,[0,0.5,2*pi/N 0],[inf 8 inf N/(2*pi)],options); % likelihood
x1=xN(1:3); x4=xN(4);
%% Plots over different types of spectra, to show why we proposes the 4 parameter model
scrsz = get(0,'ScreenSize'); Fig4=figure('Position',[1 1 scrsz(3)/1.2 scrsz(3)/2.2]);
%%%
h1=subplot(2,2,1); plot(omega([1:floor(N/2) floor(N/2)+2:N]),10*log10(SZT([1:floor(N/2) floor(N/2)+2:N])),'color','k','linewidth',1.5); % figure of periodogram
ylabel('S_{zz}(\omega) (dB)'); xlabel('\omega (cycles per day)')
ESF3 = x1(1)^2./(x1(3).^2+omega.^2).^x1(2);
hold on; plot(omega,10*log10(ESF3),'g','linewidth',1.5); % plot of this over periodogramcv
hold on; plot(omega,10*log10(ESF3),'r','linewidth',1.5,'linestyle','-.'); % plot of this over periodogramcv
xlim([-0.4*pi 0.4*pi]); ylim([60 110]);
ax = gca;
ax.XTick = [-0.4*pi,-0.2*pi,0,0.2*pi,0.4*pi];
ax.XTickLabel = {'-0.2','-0.1','0','0.1','0.2'};
ax.YTick = [40,60,80,100];
legend('multitaper',['isotropic Mat' char(233) 'rn'],['anisotropic Mat' char(233) 'rn'],'location','South');
%%%
h3=subplot(2,2,3); plot(omega(floor(N/2)+1:N),10*log10(SXT(floor(N/2)+1:N)),'color','k','linewidth',1.5); ylabel('S_{uu}(\omega) (dB)'); xlabel('\omega (cycles per day)')
hold on; plot(omega,10*log10(ESF3/2),'g','linewidth',1.5); % plot of this over periodogram
ESF5 = max(0,1-abs(x4.*omega)).*x1(1)^2./(omega.^2+x1(3)^2).^x1(2);
hold on; plot(omega(floor(N/2)+1:N),10*log10((ESF3(floor(N/2)+1:N)+ESF5(floor(N/2)+1:N))./2),'r','linestyle','-.','linewidth',1.5);
xlim([0 0.4*pi]); ylim([60 110]);
ax = gca;
ax.XTick = [0,0.1*pi,0.2*pi,0.3*pi,0.4*pi];
ax.XTickLabel = {'0','0.05','0.1','0,15','0.2'};
ax.YTick = [40,60,80,100];
legend('multitaper',['isotropic Mat' char(233) 'rn'],['anisotropic Mat' char(233) 'rn'],'location','NorthEast');
%%%
h4=subplot(2,2,4); plot(omega(floor(N/2)+1:N),10*log10(SYT(floor(N/2)+1:N)),'color','k','linewidth',1.5); ylabel('S_{vv}(\omega) (dB)'); xlabel('\omega (cycles per day)')
hold on; plot(omega,10*log10(ESF3/2),'g','linewidth',1.5); % plot of this over periodogram
hold on; plot(omega(floor(N/2)+1:N),10*log10((ESF3(floor(N/2)+1:N)-ESF5(floor(N/2)+1:N))./2),'r','linestyle','-.','linewidth',1.5);
xlim([0 0.4*pi]); ylim([60 110]);
ax = gca;
ax.XTick = [0,0.1*pi,0.2*pi,0.3*pi,0.4*pi];
ax.XTickLabel = {'0','0.05','0.1','0,15','0.2'};
ax.YTick = [40,60,80,100];
legend('multitaper',['isotropic Mat' char(233) 'rn'],['anisotropic Mat' char(233) 'rn'],'location','NorthEast');
%%%
h2=subplot(2,2,2); plot(omega(floor(N/2)+1:N),real(SZCT(floor(N/2)+1:N))./sqrt(SZT(floor(N/2)+1:N).*SZT(floor(N/2)+1:-1:1)),'color','k','linewidth',1.5);
ylabel('\Re\{\rho_{+-}(\omega)\}'); xlabel('\omega (cycles per day)');
hold on; plot(omega(floor(N/2)+1:N),zeros(1,length(omega(floor(N/2)+1:N))),'g','linewidth',1.5);
hold on; plot(omega(floor(N/2)+1:N),ESF5(floor(N/2)+1:N)./ESF3(floor(N/2)+1:N),'r','linestyle','-.','linewidth',1.5);
xlim([0 0.4*pi]); ylim([-1 1]);
ax = gca;
ax.XTick = [0,0.1*pi,0.2*pi,0.3*pi,0.4*pi];
ax.XTickLabel = {'0','0.05','0.1','0,15','0.2'};
ax.YTick = [-1,-.5,0,.5,1];
legend('multitaper',['isotropic Mat' char(233) 'rn'],['anisotropic Mat' char(233) 'rn'],'location','SouthEast');
%%%
exportfig(Fig4, 'Fig4.eps', 'width', 48, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);