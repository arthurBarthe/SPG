load QGBetaPlaneTurbulenceFloats_experiment_04.mat
%%
for ii = 1:256
    cvx=std(real(cv(:,ii)));
    cvy=std(imag(cv(:,ii)));
    CVS(:,ii)=xcov(real(cv(:,ii)),imag(cv(:,ii)),'biased')/(cvx*cvy); % biased autocorrelation
end
Fig3=figure; 
plot(-1000:1000,mean(CVS,2),'k','linewidth',1.5)
xlabel('lag (\tau)'); ylabel('s_{uv}(\tau)'); ylim([-0.025 0.025]);
exportfig(Fig3, 'Fig3.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);