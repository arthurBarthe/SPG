function [acvs,rels] = complexAR1acvs(R,N)
acvs = zeros(1,N);
rels = zeros(1,N);
R(7) = conj(R(6));
INVM = complexAR1inv(R(1:4)); % computes analytically
%INVM = inv([1-R(1)^2-R(3)^2 -R(1)*R(3)*exp(1i*(R(2)-R(4))) -R(1)*R(3)*exp(1i*(R(4)-R(2))); -2*R(1)*R(3)*exp(1i*(R(2)+R(4))) 1-R(1)^2*exp(2*1i*R(2)) -R(3)^2*exp(2*1i*R(4)); -2*R(1)*R(3)*exp(-1i*(R(2)+R(4))) -R(3)^2*exp(-2*1i*R(4)) 1-R(1)^2*exp(-2*1i*R(2))]);
% Equation (12)
acvs(1) = INVM(1,1:3)*transpose(R(5:7));
rels(1) = INVM(2,1:3)*transpose(R(5:7));
% Equations (13) and (14)
for ii = 2:N
    acvs(ii)=R(1)*exp(-1i*R(2))*acvs(ii-1)+R(3)*exp(-1i*R(4))*rels(ii-1);
    rels(ii)=R(3)*exp(1i*R(4))*acvs(ii-1)+R(1)*exp(1i*R(2))*rels(ii-1);
end