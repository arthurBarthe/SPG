R = [0.99 pi/6 0.099 -pi/4 1]; % parameters
R(6) = R(5)*(R(3)/(R(1)*abs(sin(R(2)))))*exp(1i*(R(4)+sign(R(2))*pi/2)); % relation at lag zero
[sig,rel]=complexAR1acvs(R,1); % autocovariance and relation of our model
[sig2,rel2]=complexAR1acvs([R(1) R(2) 0 0 R(5) R(6)],1); % autocovariance and relation of Picinbono and Bondon model
rng(11) % set the seed
N = 512; M = 1;
Z1 = zeros(N,M); Z2 = zeros(N,M);
% initial value
corr=imag(rel)/(sqrt(sig-real(rel))*sqrt(sig+real(rel)));
corr2=imag(rel2)/(sqrt(sig2-real(rel2))*sqrt(sig2+real(rel2)));
s1 = (sig+real(rel))/2; s2 = (sig-real(rel))/2;
s3 = (sig2+real(rel2))/2; s4 = (sig2-real(rel2))/2;
B1 = randn(1,M); C1 = randn(1,M); D1 = corr*B1 + sqrt(1-corr^2)*C1;
D2 = corr2*B1 + sqrt(1-corr2^2)*C1;
A1 = sqrt(s1)*B1; A2 = sqrt(s2)*D1;
A3 = sqrt(s3)*B1; A4 = sqrt(s4)*D2;
Z1(1,:) = A1+1i.*A2;
Z2(1,:) = A3+1i.*A4;
% the rest of the sequence
for ii = 2:N;
    corr=imag(R(6))/(sqrt(R(5)-real(R(6)))*sqrt(R(5)+real(R(6))));
    B1 = randn(1,M); C1 = randn(1,M); D1 = corr*B1 + sqrt(1-corr^2)*C1;
    s1 = (R(5)+real(R(6)))/2; s2 = (R(5)-real(R(6)))/2;
    A1 = sqrt(s1)*B1; A2 = sqrt(s2)*D1;
    Z1(ii,:) = R(1)*exp(1i*R(2))*Z1(ii-1,:)+R(3)*exp(1i*R(4))*conj(Z1(ii-1,:))+A1+1i.*A2;
    Z2(ii,:) = R(1)*exp(1i*R(2))*Z2(ii-1,:)+A1+1i.*A2;
end
%% plot (a)
scrsz=get(0,'ScreenSize'); FigNew=figure('Position',[1 1 800 600]);
subplot(2,2,1); plot(Z1,'color',[.7 .7 .7]); 
xlim([-12 12]); ylim([-12 12]); axis square; xlabel('X_t'); ylabel('Y_t');
text(0.5,1.08,'(a)','Units', 'Normalized', 'VerticalAlignment', 'Top')
set(gca,'XTick',[-12 -8 -4 0 4 8 12]);
set(gca,'YTick',[-12 -8 -4 0 4 8 12]);
[a1,b1]=complexAR1acvs(R,2);
varx=0.5*(a1(1)+real(b1(1)));
vary=0.5*(a1(1)-real(b1(1)));
exy=0.5*imag(b1(1));
Sigma=[varx exy; exy vary];
[V, D]=eig(Sigma);
ecc=(D(1,1)/D(2,2))^(.25);
ori=atan2(V(2,2),V(1,2))+pi;
ME3 = sqrt(sqrt(D(1,1)*D(2,2)))*sqrt(2)*exp(1i*(0:0.01:2*pi));
ME4 = (cos(ori)*(1/ecc)*real(ME3)-sin(ori)*ecc*imag(ME3))+1i*(cos(ori)*ecc*imag(ME3)+sin(ori)*(1/ecc)*real(ME3));
hold on; plot(ME4,'linestyle','--','linewidth',2,'color','k');
%% plot (b)
subplot(2,2,2); plot(Z2,'color',[.7 .7 .7]);
[a1,b1]=complexAR1acvs([R(1) R(2) 0 0 R(5) R(6)],1);
varx=0.5*(a1+real(b1));
vary=0.5*(a1-real(b1));
exy=0.5*imag(b1);
Sigma=[varx exy; exy vary];
[V, D]=eig(Sigma);
ecc=(D(1,1)/D(2,2))^(.25);
ori=atan2(V(2,2),V(1,2))+pi;
ME3 = sqrt(sqrt(D(1,1)*D(2,2)))*sqrt(2)*exp(1i*(0:0.01:2*pi));
ME4 = (cos(ori)*(1/ecc)*real(ME3)-sin(ori)*ecc*imag(ME3))+1i*(cos(ori)*ecc*imag(ME3)+sin(ori)*(1/ecc)*real(ME3));
hold on; plot(ME4,'linestyle','--','linewidth',2,'color','k');
xlim([-12 12]); ylim([-12 12]); axis square; xlabel('X_t'); ylabel('Y_t');
text(0.5,1.08,'(b)','Units', 'Normalized', 'VerticalAlignment', 'Top')
set(gca,'XTick',[-12 -8 -4 0 4 8 12]);
set(gca,'YTick',[-12 -8 -4 0 4 8 12]);
%%
R = [0.297 pi/6 0.099 -pi/4 1]; % parameters
R(6) = R(5)*(R(3)/(R(1)*sin(R(2))))*exp(1i*(R(4)+pi/2)); % relation at lag zero
[sig,rel]=complexAR1acvs(R,1); % autocovariance and relation of our model
[sig2,rel2]=complexAR1acvs([R(1) R(2) 0 0 R(5) R(6)],1); % autocovariance and relation of Picinbono and Bondon model
rng(12); % set the seed
N = 512; M = 1;
Z1 = zeros(N,M); Z2 = zeros(N,M);
% initial value
corr=imag(rel)/(sqrt(sig-real(rel))*sqrt(sig+real(rel)));
corr2=imag(rel2)/(sqrt(sig2-real(rel2))*sqrt(sig2+real(rel2)));
s1 = (sig+real(rel))/2; s2 = (sig-real(rel))/2;
s3 = (sig2+real(rel2))/2; s4 = (sig2-real(rel2))/2;
B1 = randn(1,M); C1 = randn(1,M); D1 = corr*B1 + sqrt(1-corr^2)*C1;
D2 = corr2*B1 + sqrt(1-corr2^2)*C1;
A1 = sqrt(s1)*B1; A2 = sqrt(s2)*D1;
A3 = sqrt(s3)*B1; A4 = sqrt(s4)*D2;
Z1(1,:) = A1+1i.*A2;
Z2(1,:) = A3+1i.*A4;
% the rest of the sequence
for ii = 2:N;
    corr=imag(R(6))/(sqrt(R(5)-real(R(6)))*sqrt(R(5)+real(R(6))));
    B1 = randn(1,M); C1 = randn(1,M); D1 = corr*B1 + sqrt(1-corr^2)*C1;
    s1 = (R(5)+real(R(6)))/2; s2 = (R(5)-real(R(6)))/2;
    A1 = sqrt(s1)*B1; A2 = sqrt(s2)*D1;
    Z1(ii,:) = R(1)*exp(1i*R(2))*Z1(ii-1,:)+R(3)*exp(1i*R(4))*conj(Z1(ii-1,:))+A1+1i.*A2;
    Z2(ii,:) = R(1)*exp(1i*R(2))*Z2(ii-1,:)+A1+1i.*A2;
end
%% plot (c)
subplot(2,2,3); plot(Z1,'color',[.7 .7 .7]); 
xlim([-4 4]); ylim([-4 4]); axis square; xlabel('X_t'); ylabel('Y_t');
text(0.5,1.08,'(c)','Units', 'Normalized', 'VerticalAlignment', 'Top')
set(gca,'XTick',[-4 -3 -2 -1 0 1 2 3 4]);
set(gca,'YTick',[-4 -3 -2 -1 0 1 2 3 4]);
[a1,b1]=complexAR1acvs(R,1);
varx=0.5*(a1+real(b1));
vary=0.5*(a1-real(b1));
exy=0.5*imag(b1);
Sigma=[varx exy; exy vary];
[V, D]=eig(Sigma);
ecc=(D(1,1)/D(2,2))^(.25);
ori=atan2(V(2,2),V(1,2))+pi;
sqrt(2)*Theta1(5)/sqrt(1-Theta1(1)^2)
sqrt(sqrt(D(1,1)*D(2,2)))
ME3 = sqrt(sqrt(D(1,1)*D(2,2)))*sqrt(2)*exp(1i*(0:0.01:2*pi));
ME4 = (cos(ori)*(1/ecc)*real(ME3)-sin(ori)*ecc*imag(ME3))+1i*(cos(ori)*ecc*imag(ME3)+sin(ori)*(1/ecc)*real(ME3));
hold on; plot(ME4,'linestyle','--','linewidth',2,'color','k');
%% plot (d)
subplot(2,2,4); plot(Z2,'color',[.7 .7 .7]);
[a1,b1]=complexAR1acvs([R(1) R(2) 0 0 R(5) R(6)],1);
varx=0.5*(a1+real(b1));
vary=0.5*(a1-real(b1));
exy=0.5*imag(b1);
Sigma=[varx exy; exy vary];
[V, D]=eig(Sigma);
ecc=(D(1,1)/D(2,2))^(.25);
ori=atan2(V(2,2),V(1,2))+pi;
ME3 = sqrt(sqrt(D(1,1)*D(2,2)))*sqrt(2)*exp(1i*(0:0.01:2*pi));
ME4 = (cos(ori)*(1/ecc)*real(ME3)-sin(ori)*ecc*imag(ME3))+1i*(cos(ori)*ecc*imag(ME3)+sin(ori)*(1/ecc)*real(ME3));
hold on; plot(ME4,'linestyle','--','linewidth',2,'color','k');
xlim([-4 4]); ylim([-4 4]); axis square; xlabel('X_t'); ylabel('Y_t');
text(0.5,1.08,'(d)','Units', 'Normalized', 'VerticalAlignment', 'Top')
set(gca,'XTick',[-4 -3 -2 -1 0 1 2 3 4]);
set(gca,'YTick',[-4 -3 -2 -1 0 1 2 3 4]);
h=subplot(2,2,2);
p = get(h, 'pos'); p(1) = p(1) - 0.1; set(h, 'pos', p)
h=subplot(2,2,3);
p = get(h, 'pos'); p(2) = p(2) + 0.03; set(h, 'pos', p)
h=subplot(2,2,4);
p = get(h, 'pos'); p(2) = p(2) + 0.03; p(1) = p(1) - 0.1; set(h, 'pos', p)
exportfig(FigNew, 'FigNew.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 18);