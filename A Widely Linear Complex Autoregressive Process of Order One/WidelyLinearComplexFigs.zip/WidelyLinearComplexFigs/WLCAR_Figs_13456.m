%%
close all
load paslhz2.dat
load pashlhr2.dat
load SPECD.mat
load SPECM.mat
load CRPECD.mat
load CRPECM.mat
load CIPECD.mat
load CIPECM.mat
load PARAM.mat
load PARAM2.mat
load ESF3long.mat
load SZlong.mat
load CI.mat
load SC1.mat
load SC2.mat
load FTD.mat
%% SEISMIC TIME SERIES
for k=0:839
for j=1:5
y(5*k+j)=paslhz2(k+1,j);
end;
end;
for k=0:839
for j=1:5
x(5*k+j)=pashlhr2(k+1,j);
end;
end;
zz1 = x+1i.*y; zz2 = (zz1)/1000;
%% FIG 1
scrsz=get(0,'ScreenSize'); Fig1=figure('Position',[1 1 800 300]);
set(0,'defaultAxesFontName', 'times')
subplot(2,2,1); plot(x(1500:3150)/10000,'k'); ylabel('X_t \times 10^4');  xlim([0 1650]); ylim([-17 17]);
hold on; line([600 600],[-17 17],'color','k','linestyle','--')
hold on; line([1359 1359],[-17 17],'color','k','linestyle','--')
ax = gca;
xx = [185,485,785,1085,1385];
xxx = [];
set(gca,'XTick',xx)
set(gca,'XTickLabel',sprintf('%2.2f\n',xxx))
subplot(2,2,3); plot(y(1500:3150)/10000,'k'); ylabel('Y_t \times 10^4'); xlabel('time (UTC)');  xlim([0 1650]); ylim([-17 17]);
hold on; line([600 600],[-17 17],'color','k','linestyle','--')
hold on; line([1359 1359],[-17 17],'color','k','linestyle','--')
set(gca,'XTick',[185,485,785,1085,1385],...
        'XTickLabel',{'16:25','16:30','16:35','16:40','16:45'});
subplot(2,2,[2 4]); plot(zz1(2100:2860)/10000,'k'); xlabel('X_t \times 10^4'); ylabel('Y_t \times 10^4');
xlim([-14.5 12.5]); ylim([-16.7 15]); 
axis equal;
xx = [-15,-10,-5,0,5,10,15];
set(gca,'XTick',xx)
set(gca,'YTick',xx)
h=subplot(2,2,1);
text(0.5,1.2,'(a)','Units', 'Normalized', 'VerticalAlignment', 'Top')
p = get(h, 'pos'); p(2) = p(2) + 0.073; set(h, 'pos', p);
h=subplot(2,2,[2 4]);
text(0.5,1.085,'(c)','Units', 'Normalized', 'VerticalAlignment', 'Top')
p = get(h, 'pos'); p(2) = p(2) + 0.073; set(h, 'pos', p);
h=subplot(2,2,3);
text(0.5,1.2,'(b)','Units', 'Normalized', 'VerticalAlignment', 'Top')
p = get(h, 'pos'); p(2) = p(2) + 0.075; set(h, 'pos', p);
exportfig(Fig1, 'Fig1.eps', 'width', 16,'Fontmode','fixed','FontSize', 24);
%% FIG 3
N=161; omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi;
N2=761; omega2=0:2*pi/N2:2*pi*(1-1/N2); omega2=fftshift(omega2); omega2(1:floor(N2/2))=omega2(1:floor(N2/2))-2*pi;
Fig3=figure('Position',[1 1 800 600]);
subplot(2,2,1); plot(omega2,10*log10(SZ),'k','linewidth',2); xlim([-pi pi]); ylim([-20 70]);
hold on; plot(omega2,10*log10(ESF3),'color',[0.7 0.7 0.7],'linestyle','--','linewidth',1.5);
hold on; plot(omega2(286:476),10*log10(ESF3(286:476)),'color',[0.7 0.7 0.7],'linewidth',1.5); ylabel('power (dB)'); xlabel('frequency (\omega, rad/s)');
hold on; line([-pi/4 -pi/4],[-20 70],'color','k','linestyle','--')
hold on; line([pi/4 pi/4],[-20 70],'color','k','linestyle','--')
ax = gca;
ax.YTick = [-20 -10 0 10 20 30 40 50 60 70];
ax.YTickLabel = {'40','50','60','70','80','90','100','110','120','130'};
ax.XTick = [-pi -pi/2 -pi/4 0 pi/4 pi/2 pi];
ax.XTickLabel = {'-\pi','-\pi/2','-\pi/4','0','\pi/4','\pi/2','\pi'};
subplot(2,2,2); plot(zz1(2210:2370)/10000,'k');
hold on; plot(zz1(2483:2643)/10000,'color',[0.7 0.7 0.7]);
xlabel('X_t \times 10^4'); ylabel('Y_t \times 10^4');
xlim([-17 17]); ylim([-17 17]); axis equal
subplot(2,2,3); plot(omega,10*log10(SPECD(595,:)),'k','linewidth',2); xlim([-pi pi]); ylim([0 70]);
hold on; plot(omega,10*log10(SPECM(595,:)),'color',[0.7 0.7 0.7],'linestyle','--','linewidth',1.5);
hold on; plot(omega(61:101),10*log10(SPECM(595,61:101)),'color',[0.7 0.7 0.7],'linewidth',1.5); ylabel('power (dB)'); xlabel('frequency (\omega, rad/s)'); 
hold on; line([-pi/4 -pi/4],[-20 70],'color','k','linestyle','--')
hold on; line([pi/4 pi/4],[-20 70],'color','k','linestyle','--')
ax = gca;
ax.YTick = [0 10 20 30 40 50 60 70];
ax.YTickLabel = {'60','70','80','90','100','110','120','130'};
ax.XTick = [-pi -pi/2 -pi/4 0 pi/4 pi/2 pi];
ax.XTickLabel = {'-\pi','-\pi/2','-\pi/4','0','\pi/4','\pi/2','\pi'};
subplot(2,2,4); plot(omega,10*log10(SPECD(868,:)),'k','linewidth',2); xlim([-pi pi]); ylim([0 70]);
hold on; plot(omega,10*log10(SPECM(868,:)),'color',[0.7 0.7 0.7],'linestyle','--','linewidth',1.5);
hold on; plot(omega(61:101),10*log10(SPECM(868,61:101)),'color',[0.7 0.7 0.7],'linewidth',1.5); ylabel('power (dB)'); xlabel('frequency (\omega, rad/s)');
hold on; line([-pi/4 -pi/4],[-20 70],'color','k','linestyle','--')
hold on; line([pi/4 pi/4],[-20 70],'color','k','linestyle','--')
ax = gca;
ax.YTick = [0 10 20 30 40 50 60 70];
ax.YTickLabel = {'60','70','80','90','100','110','120','130'};
ax.XTick = [-pi -pi/2 -pi/4 0 pi/4 pi/2 pi];
ax.XTickLabel = {'-\pi','-\pi/2','-\pi/4','0','\pi/4','\pi/2','\pi'};
subplot(2,2,1)
text(0.5,1.1,'(a)','Units', 'Normalized', 'VerticalAlignment', 'Top')
subplot(2,2,2)
text(0.5,1.1,'(b)','Units', 'Normalized', 'VerticalAlignment', 'Top')
subplot(2,2,3)
text(0.5,1.1,'(c)','Units', 'Normalized', 'VerticalAlignment', 'Top')
subplot(2,2,4)
text(0.5,1.1,'(d)','Units', 'Normalized', 'VerticalAlignment', 'Top')
h=subplot(2,2,1);
p = get(h, 'pos'); p(2) = p(2) - 0.01; set(h, 'pos', p)
h=subplot(2,2,2);
p = get(h, 'pos'); p(2) = p(2) - 0.01; set(h, 'pos', p)
exportfig(Fig3, 'Fig3.eps', 'width', 16, 'color', 'cmyk','Fontmode','fixed','FontSize', 24);
%% FIG4
Fig4=figure('Position',[1 1 800 600]); colormap('jet')
SPECM(:,81)=0; CRPECM(:,81)=0; CIPECM(:,81)=0;
subplot(2,2,1); image(485:1084,omega(61:101),10*log10(SPECD(485:1084,61:101)'));
set(gca,'YDir','normal')
ax = gca;
ax.YTick = [-pi/4 -pi/8 0 pi/8 pi/4];
ax.YTickLabel = {'-\pi/4','-\pi/8','0','\pi/8','\pi/4'};
ax.XTick = [529,709,889,1049];
ax.XTickLabel = {'16:34','16:37','16:40','16:43'};
hcb=colorbar;
set(hcb,'YTick',[10 20 30 40 50 60],'YTickLabel',[70 80 90 100 110 120]) 
ylabel('frequency (\omega, rad/s)'); 
subplot(2,2,2); image(485:1084,omega(61:101),10*log10(SPECM(485:1084,61:101)')); colorbar
set(gca,'YDir','normal')
ax = gca;
ax.YTick = [-pi/4 -pi/8 0 pi/8 pi/4];
ax.YTickLabel = {'-\pi/4','-\pi/8','0','\pi/8','\pi/4'};
ax.XTick = [529,709,889,1049];
ax.XTickLabel = {'16:34','16:37','16:40','16:43'};
hcb=colorbar;
set(hcb,'YTick',[10 20 30 40 50 60],'YTickLabel',[70 80 90 100 110 120]) 
subplot(2,2,3); image(485:1084,omega(61:101),10*log10(sqrt(CIPECD(485:1084,61:101)'.^2+CRPECD(485:1084,61:101)'.^2)));
set(gca,'YDir','normal')
ax = gca;
ax.YTick = [-pi/4 -pi/8 0 pi/8 pi/4];
ax.YTickLabel = {'-\pi/4','-\pi/8','0','\pi/8','\pi/4'};
ax.XTick = [529,709,889,1049];
ax.XTickLabel = {'16:34','16:37','16:40','16:43'};
hcb=colorbar;
set(hcb,'YTick',[10 20 30 40 50 60],'YTickLabel',[70 80 90 100 110 120])
xlabel('time (UTC)'); ylabel('frequency (\omega, rad/s)'); 
subplot(2,2,4); image(485:1084,omega(61:101),10*log10(sqrt(CIPECM(485:1084,61:101)'.^2+CRPECM(485:1084,61:101)'.^2))); colorbar
set(gca,'YDir','normal')
ax = gca;
ax.YTick = [-pi/4 -pi/8 0 pi/8 pi/4];
ax.YTickLabel = {'-\pi/4','-\pi/8','0','\pi/8','\pi/4'};
ax.XTick = [529,709,889,1049];
ax.XTickLabel = {'16:34','16:37','16:40','16:43'};
hcb=colorbar;
set(hcb,'YTick',[10 20 30 40 50 60],'YTickLabel',[70 80 90 100 110 120])
xlabel('time (UTC)');
subplot(2,2,1)
text(0.5,1.1,'(a)','Units', 'Normalized', 'VerticalAlignment', 'Top')
subplot(2,2,2)
text(0.5,1.1,'(b)','Units', 'Normalized', 'VerticalAlignment', 'Top')
subplot(2,2,3)
text(0.5,1.1,'(c)','Units', 'Normalized', 'VerticalAlignment', 'Top')
subplot(2,2,4)
text(0.5,1.1,'(d)','Units', 'Normalized', 'VerticalAlignment', 'Top')
h=subplot(2,2,1);
p = get(h, 'pos'); p(2) = p(2) - 0.01; set(h, 'pos', p)
h=subplot(2,2,2);
p = get(h, 'pos'); p(2) = p(2) - 0.01; p(1) = p(1) - 0.02; set(h, 'pos', p)
h=subplot(2,2,3);
p = get(h, 'pos'); p(2) = p(2) + 0.01; set(h, 'pos', p)
h=subplot(2,2,4);
p = get(h, 'pos'); p(2) = p(2) + 0.01; p(1) = p(1) - 0.02; set(h, 'pos', p)
exportfig(Fig4, 'Fig4.eps', 'width', 16,'color', 'cmyk','Fontmode','fixed','FontSize', 24);
%% FIG5
Fig5=figure('Position',[1 1 800 300]);
subplot(1,2,1); xlim([484 1083]);
boundedline(485:1084,smooth(sqrt(1-PARAM(485:1084,3).^4),11),smooth(1.96*sqrt(4*PARAM(485:1084,3).^6./(1-PARAM(485:1084,3).^4).*CI(485:1084,1)),11),'k');
cc=sqrt(max(SPECD(485:1084,82:161)'));
dd=sqrt(max(SPECD(485:1084,1:80)'));
hold on; plot(485:1084,smooth(2*sqrt(dd.*cc)./(cc+dd),11),'r','linestyle','--')
ax=gca;
ax.XTick = [529,709,889,1049];
ax.XTickLabel = {'16:34','16:37','16:40','16:43'};
xlabel('time (UTC)'); ylabel(['eccentricity (',char(949),')']); box ON
subplot(1,2,2); xlim([484 1083]);
boundedline(485:1084,smooth(PARAM(485:1084,4),11),smooth(1.96*sqrt(CI(485:1084,2)),11),'k');
[dum1,dum2]=max(sqrt(SPECD(485:1084,1:80))'); dang=[];
for ii = 485:1084
dang(ii)=atan(imag(FTD(ii,dum2(ii-484)))/real(FTD(ii,dum2(ii-484))));
dang2(ii)=atan(imag(FTD(ii,162-dum2(ii-484)))/real(FTD(ii,162-dum2(ii-484))));
end
DNG=mod(0.5*(dang(485:1084)+dang2(485:1084)),pi/2);
for jj = 1:length(DNG)
    if DNG(jj)<0.6
        DNG(jj)=DNG(jj)+pi/2;
    end
end
hold on; plot(485:1084,smooth(DNG,11),'r','linestyle','--')
ax=gca;
ax.XTick = [529,709,889,1049];
ax.XTickLabel = {'16:34','16:37','16:40','16:43'};
ylim([0.5 2.2]);
ax.YTick = [pi/4 3*pi/8 pi/2 5*pi/8];
ax.YTickLabel = {'\pi/4','3\pi/8','\pi/2','5\pi/8'};
xlabel('time (UTC)'); ylabel('orientation (\psi)'); box ON
h=subplot(1,2,1);
text(0.5,1.09,'(a)','Units', 'Normalized', 'VerticalAlignment', 'Top')
p = get(h, 'pos'); p(2) = p(2) + 0.05; set(h, 'pos', p)
h=subplot(1,2,2);
text(0.5,1.09,'(b)','Units', 'Normalized', 'VerticalAlignment', 'Top')
p = get(h, 'pos'); p(2) = p(2) + 0.05; set(h, 'pos', p)
exportfig(Fig5, 'Fig5.eps', 'width', 16,'color', 'cmyk','Fontmode','fixed','FontSize', 24);
%% FIG 6 - FDR Procedure
for ii = 1:11
WW(ii)=mean(2*(SC2(1+(ii-1)*161:161+(ii-1)*161)-SC1(1+(ii-1)*161:161+(ii-1)*161)));
end
chi2inv(1-.05.*(1:11)/11,2)
%% FIG 6
Fig6=figure('Position',[1 1 800 300]);
plot(1:1771,smooth(2*(SC2(1:1771)-SC1(1:1771)),11),'color',[0.5 0.5 0.5]); xlim([1 1771]); xlabel('time (UTC)'); ylabel('W');
hold on; line([1 1771],[chi2inv(0.95,2) chi2inv(0.95,2)],'color','k','linestyle','--');
hold on; line([161 161],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([1 161],[mean(2*(SC2(1:161)-SC1(1:161))) mean(2*(SC2(1:161)-SC1(1:161)))],'color','k');
hold on; line([322 322],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([161 322],[mean(2*(SC2(162:322)-SC1(162:322))) mean(2*(SC2(162:322)-SC1(162:322)))],'color','k');
hold on; line([402 402],[0 200],'color','k');
hold on; line([485 485],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([322 483],[mean(2*(SC2(323:483)-SC1(323:483))) mean(2*(SC2(323:483)-SC1(323:483)))],'color','k');
hold on; line([644 644],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([483 644],[mean(2*(SC2(484:644)-SC1(484:644))) mean(2*(SC2(484:644)-SC1(484:644)))],'color','k');
hold on; line([805 805],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([644 805],[mean(2*(SC2(645:805)-SC1(645:805))) mean(2*(SC2(645:805)-SC1(645:805)))],'color','k');
hold on; line([966 966],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([805 966],[mean(2*(SC2(806:966)-SC1(806:966))) mean(2*(SC2(806:966)-SC1(806:966)))],'color','k');
hold on; line([1127 1127],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([966 1127],[mean(2*(SC2(967:1127)-SC1(967:1127))) mean(2*(SC2(967:1127)-SC1(967:1127)))],'color','k');
hold on; line([1163 1163],[0 200],'color','k');
hold on; line([1288 1288],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([1127 1288],[mean(2*(SC2(1128:1288)-SC1(1128:1288))) mean(2*(SC2(1128:1288)-SC1(1128:1288)))],'color','k');
hold on; line([1449 1449],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([1288 1449],[mean(2*(SC2(1289:1449)-SC1(1289:1449))) mean(2*(SC2(1289:1449)-SC1(1289:1449)))],'color','k');
hold on; line([1610 1610],[0 200],'color',[0.7 0.7 0.7],'linestyle','--');
hold on; line([1449 1610],[mean(2*(SC2(1450:1610)-SC1(1450:1610))) mean(2*(SC2(1450:1610)-SC1(1450:1610)))],'color','k');
hold on; line([1610 1771],[mean(2*(SC2(1611:1771)-SC1(1611:1771))) mean(2*(SC2(1611:1771)-SC1(1611:1771)))],'color','k');
ax=gca;
ax.XTick = [58,298,538,778,1018,1258,1498,1738];
ax.XTickLabel = {'16:26','16:30','16:34','16:38','16:42','16:46','16:50','16:54'};
exportfig(Fig6, 'Fig6.eps', 'width', 16,'color', 'cmyk','Fontmode','fixed','FontSize', 24);