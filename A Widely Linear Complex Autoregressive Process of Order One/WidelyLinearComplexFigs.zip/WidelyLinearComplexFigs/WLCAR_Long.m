%% THE DATA
load paslhz2.dat
load pashlhr2.dat
for k=0:839
for j=1:5
y(5*k+j)=paslhz2(k+1,j);
end;
end;
for k=0:839
for j=1:5
x(5*k+j)=pashlhr2(k+1,j);
end;
end;
zz1 = x+1i.*y; zz2 = (zz1)/1000;
%% PRELIM
options=optimset('gradobj','on','MaxFunEval',10000); % Fminsearch choices
N = 761; MF = floor(N/2)+1; PC=.25; % Time and frequency windows
Q = [.998 .3 .9 pi/2-.3 10]; % Starting values for Whittle
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % Fourier frequencies
ZZ = zz2(2101:2861); % The data
ZZ = ZZ-mean(ZZ); JX=1/sqrt(N)*fft(real(ZZ)); JY=1/sqrt(N)*fft(imag(ZZ)); % Fourier transform
%% Spectrum
SZ = (abs(JX+1i*JY)).^2; SZ = fftshift(SZ); SZ(MF)=NaN(1); % Spectra
%% Whittle Likelihood
x1b=fminsearchbnd(@(x) complexAR1model(x,JX,JY,N,PC,MF),Q,[0 -pi 0 -pi 0],[.999 pi 1 pi inf],options);
%% Expected periodogram
R1=zeros(1,6); R1(1)=x1b(1)*sqrt(cos(x1b(2))^2+0.25*sin(x1b(2))^2*(1/x1b(3)^2+x1b(3)^2)^2); 
R1(2)=atan2(0.5*(1/x1b(3)^2+x1b(3)^2)*sin(x1b(2)),cos(x1b(2)));
R1(3)=(x1b(1)/2)*sin(x1b(2))*(1/x1b(3)^2-x1b(3)^2);
if x1b(4) <= 3*pi/4 
    R1(4)=-pi/2+2*x1b(4);
else
    R1(4)=-5*pi/2+2*x1b(4);
end
R1(5)=x1b(5)*(1/x1b(3)^2+x1b(3)^2); 
R1(6)=x1b(5)*(1/x1b(3)^2-x1b(3)^2)*(cos(2*x1b(4))+1i*sin(2*x1b(4)));
[acvs,rels]=complexAR1acvs(R1,N); acvs(1)=real(acvs(1)); ESF2=2*fft(conj(acvs).*(1-(0:N-1)/N))-acvs(1); ESF3=real(fftshift(ESF2));
save('SZlong.mat','SZ'); save('ESF3long.mat','ESF3')