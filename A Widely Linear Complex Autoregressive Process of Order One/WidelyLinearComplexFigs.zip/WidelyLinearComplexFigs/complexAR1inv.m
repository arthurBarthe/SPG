function [INVM,DETM] = complexAR1inv(R)
%% Provides analytic form for inverse matrix in equation (12)
DETM = 1-R(1)^2-R(3)^2+R(1)^4-R(3)^4-R(1)^6+R(3)^6-3*R(1)^2*R(3)^4+3*R(1)^4*R(3)^2+2*cos(2*R(2))*(R(1)^4-R(1)^2-R(1)^2*R(3)^2);
INVM = [1+R(1)^4-R(3)^4-R(1)^2*2*cos(2*R(2)) R(1)*R(3)*exp(1i*R(2)-1i*R(4))+(R(3)^3*R(1)-R(1)^3*R(3))*exp(-1i*R(2)-1i*R(4)) R(1)*R(3)*exp(-1i*R(2)+1i*R(4))+(R(3)^3*R(1)-R(1)^3*R(3))*exp(1i*R(2)+1i*R(4));
2*R(1)*R(3)*(exp(1i*R(2)+1i*R(4))+(R(3)^2-R(1)^2)*exp(-1i*R(2)+1i*R(4))) 1-R(1)^2-R(3)^2+exp(-2*1i*R(2))*(R(1)^4-R(1)^2-R(1)^2*R(3)^2) (R(3)^2+R(1)^2*R(3)^2-R(3)^4)*exp(2*1i*R(4));
2*R(1)*R(3)*(exp(-1i*R(2)-1i*R(4))+(R(3)^2-R(1)^2)*exp(-1i*R(4)+1i*R(2))) (R(3)^2+R(1)^2*R(3)^2-R(3)^4)*exp(-2*1i*R(4)) 1-R(1)^2-R(3)^2+exp(2*1i*R(2))*(R(1)^4-R(1)^2-R(1)^2*R(3)^2)];
INVM = INVM/DETM;