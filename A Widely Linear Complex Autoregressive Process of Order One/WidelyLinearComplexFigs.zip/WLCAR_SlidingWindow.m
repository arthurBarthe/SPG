%% THE DATA
load paslhz2.dat
load pashlhr2.dat
for k=0:839
for j=1:5
y(5*k+j)=paslhz2(k+1,j);
end;
end;
for k=0:839
for j=1:5
x(5*k+j)=pashlhr2(k+1,j);
end;
end;
zz1 = x+1i.*y; zz2 = (zz1)/1000;
%% PRELIM
options=optimset('gradobj','on','MaxFunEval',10000); % Fminsearch choices
N = 161; MF = floor(N/2)+1; PC=.25; % Time and frequency windows 
Q = [.998 -.3 .9 pi/2-.3 10]; % Starting parameters
Q2 = [.998 -.3 1 0 10]; % Starting parameters for proper model
omega=0:2*pi/N:2*pi*(1-1/N); omega=fftshift(omega); omega(1:floor(N/2))=omega(1:floor(N/2))-2*pi; % Fourier frequencies
%% SAVED PARAMS
SPECD=zeros(1771,N); % Rolling periodogram of data
SPECM=zeros(1771,N); % Rolling expected periodogram of model fit
CRPECD=zeros(1771,N); % Rolling complementary periodogram of data (real part)
CRPECM=zeros(1771,N); % Rolling expected complementary periodogram of model fit (real part)
CIPECD=zeros(1771,N); % Rolling complementary periodogram of data (imaginary part)
CIPECM=zeros(1771,N); % Rolling expected complementary periodogram of model fit (imaginary part)
PARAM=zeros(1771,5); % Rolling parameter estimates (elliptical bivariate model)
PARAM2=zeros(1771,6); % Rolling parameter estimates (complex improper model)
CI=zeros(1771,2); % Confidence interval estimates for eccentricity and ellipse orientation
SC1=zeros(1771,1); % Maximum likelihood value for improper model
SC2=zeros(1771,1); % Maximum likelihood value for proper model (for Fig 6 analysis)
FTD=zeros(1771,N); % Fourier Transform (used to calculate nonparametric estimates in Fig 5)
%% LOOP
for ii = 189:1771
    ZZ = zz2(ii+1616:ii+1616+N-1); % The data
    ZZ = ZZ-mean(ZZ); JX=1/sqrt(N)*fft(real(ZZ)); JY=1/sqrt(N)*fft(imag(ZZ)); % Fourier Transform
    SZ = (abs(JX+1i*JY)).^2; SZ = fftshift(SZ); % Spectrum
    % Various Whittle Likelihoods for 3 and 5 param model, initial values 
    % are either specified, or set as previous estimate in rolling window
    if ii > 1
        [x1b1,fval1]=fminsearchbnd(@(x) complexAR1model(x,JX,JY,N,PC,MF),Q,[0 -pi 0 -pi 0],[.999 pi 1 pi inf],options);
        [x1b,fvalIP]=fminsearchbnd(@(x) complexAR1model(x,JX,JY,N,PC,MF),x1b,[0 -pi 0 -pi 0],[.999 pi 1 pi inf],options);
        [x2b1,fval2]=fminsearchbnd(@(x) complexAR1model(x,JX,JY,N,PC,MF),Q2,[0 -pi 1 0 0],[.999 pi 1 0 inf],options);
        [x2b,fvalP]=fminsearchbnd(@(x) complexAR1model(x,JX,JY,N,PC,MF),x2b,[0 -pi 1 0 0],[.999 pi 1 0 inf],options);
        if fval1<fvalIP
            x1b=x1b1;
            fvalIP=fval1;
        end
        if fval2<fvalP
            x2b=x2b1;
            fvalP=fval2;
        end
    else
        [x1b,fvalIP]=fminsearchbnd(@(x) complexAR1model(x,JX,JY,N,PC,MF),Q,[0 -pi 0 -pi 0],[.999 pi 1 pi inf],options);
        [x2b,fvalP]=fminsearchbnd(@(x) complexAR1model(x,JX,JY,N,PC,MF),Q2,[0 -pi 1 0 0],[.999 pi 1 0 inf],options);
    end
    % Variance of rho and psi from Hessian
    whittle=@(x) complexAR1model2(x,[x1b(1) x1b(2) x1b(5)],JX,JY,N,PC,MF);
    FI=hessian(whittle,[x1b(3) x1b(4)]); IFI = inv(FI); CI(ii,:)=diag(IFI);
    % Likelihood scores for improper and proper model
    SC1(ii)=fvalIP; SC2(ii)=fvalP;
    % Computed expected periodograms and complementary spectra
    R1=zeros(1,6); R1(1)=x1b(1)*sqrt(cos(x1b(2))^2+0.25*sin(x1b(2))^2*(1/x1b(3)^2+x1b(3)^2)^2); 
    R1(2)=atan2(0.5*(1/x1b(3)^2+x1b(3)^2)*sin(x1b(2)),cos(x1b(2)));
    R1(3)=(x1b(1)/2)*sin(x1b(2))*(1/x1b(3)^2-x1b(3)^2);
    if x1b(4) <= 3*pi/4 
        R1(4)=-pi/2+2*x1b(4);
    else
        R1(4)=-5*pi/2+2*x1b(4);
    end
    R1(5)=x1b(5)*(1/x1b(3)^2+x1b(3)^2); 
    R1(6)=x1b(5)*(1/x1b(3)^2-x1b(3)^2)*(cos(2*x1b(4))+1i*sin(2*x1b(4)));
    [acvs,rels]=complexAR1acvs(R1,N); acvs(1)=real(acvs(1)); ESF2=2*fft(conj(acvs).*(1-(0:N-1)/N))-acvs(1); ESF3=real(fftshift(ESF2)); % fft of acvs with triangle kernel to find expected blurred spectrum
    SZ(MF)=NaN(1); SPECD(ii,:)=SZ; SPECM(ii,:)=ESF3; 
    SC=abs(JX).^2-abs(JY).^2; SC=fftshift(SC);
    ESF4=2*fft(real(rels).*(1-(0:N-1)/N))-real(rels(1)); ESF5=real(fftshift(ESF4)); % fft of acvs with triangle kernel to find expected blurred spectrum
    SCI=real(JX.*conj(JY)); SCI=fftshift(SCI)*2;
    ESF6=2*fft(imag(rels).*(1-(0:N-1)/N))-imag(rels(1)); ESF7=real(fftshift(ESF6)); % fft of acvs with triangle kernel to find expected blurred spectrum
    CRPECD(ii,:)=SC; CRPECM(ii,:)=ESF5; 
    CIPECD(ii,:)=SCI; CIPECM(ii,:)=ESF7;
    PARAM2(ii,:)=R1; PARAM(ii,:)=x1b;
    FT = 1/sqrt(N)*fft(ZZ); FT=fftshift(FT);
    FTD(ii,:)=FT;
end
    %% save down results
    save('SPECD.mat','SPECD')
    save('SPECM.mat','SPECM')
    save('CRPECD.mat','CRPECD')
    save('CRPECM.mat','CRPECM')
    save('CIPECD.mat','CIPECD')
    save('CIPECM.mat','CIPECM')
    save('PARAM.mat','PARAM')
    save('PARAM2.mat','PARAM2')
    save('CI.mat','CI')
    save('SC1.mat','SC1')
    save('SC2.mat','SC2')
    save('FTD.mat','FTD')