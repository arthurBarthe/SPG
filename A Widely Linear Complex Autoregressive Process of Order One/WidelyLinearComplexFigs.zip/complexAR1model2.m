function [out]=complexAR1model2(x,x2,JX,JY,N,PC,MF)
Q=[x2(1) x2(2) x(1) x(2) x2(3)];
R=zeros(1,6); 
R(1)=Q(1)*sqrt(cos(Q(2))^2+0.25*sin(Q(2))^2*(1/Q(3)^2+Q(3)^2)^2); 
R(2)=atan2(0.5*(1/Q(3)^2+Q(3)^2)*sin(Q(2)),cos(Q(2)));
R(3)=(Q(1)/2)*sin(Q(2))*(1/Q(3)^2-Q(3)^2);
if Q(4) <= 3*pi/4 
    R(4)=-pi/2+2*Q(4);
else
    R(4)=-5*pi/2+2*Q(4);
end
R(5)=Q(5)*(1/Q(3)^2+Q(3)^2); 
R(6)=Q(5)*(1/Q(3)^2-Q(3)^2)*(cos(2*Q(4))+1i*sin(2*Q(4)));
%R(1)=Q(1)*sqrt(cos(Q(2))^2+0.25*sin(Q(2))^2*(1/Q(4)^2+Q(4)^2)^2); R(2)=atan(0.5*(1/Q(4)^2+Q(4)^2)*tan(Q(2)))+pi*round(Q(2)/pi);
%R(3)=(Q(1)/2)*sin(Q(2))*(Q(4)^2-1/Q(4)^2); R(4)=pi/2+2*Q(5);
%R(5)=Q(3)*(1/Q(4)^2+Q(4)^2); R(6)=Q(3)*(cos(2*Q(5))*(1/Q(4)^2-Q(4)^2)+1i*sin(2*Q(5))*(1/Q(4)^2-Q(4)^2));
%R(6)=R(5)*sin(R(4))*(-R(3))/(R(1)*sin(R(2)))-1i*cos(R(4))*R(5)*(-R(3))/(R(1)*sin(R(2)));
[acvs,rels]=complexAR1acvs(R,N); acvs(1)=real(acvs(1));
ESF2=2*real(fft(conj(acvs).*(1-(0:N-1)/N)))-acvs(1);
ESF3=2*real(fft(real(rels).*(1-(0:N-1)/N)))-real(rels(1));
ESF4=2*real(fft(imag(rels).*(1-(0:N-1)/N)))-imag(rels(1));
SSS=zeros(2,2,MF); SSS(1,1,:)=ESF2(1:MF); SSS(2,2,:)=ESF2([1 N:-1:MF+1]);
SSS(1,2,:)=ESF3(1:MF)+1i.*ESF4(1:MF);
SSS(2,1,:)=conj(SSS(1,2,:));
ll=zeros(1,MF);
MS=SSS(1,1,:).*SSS(2,2,:)-SSS(2,1,:).*SSS(1,2,:);
for ii = 1:1+round(PC*(MF-1))
    MSI=1/MS(ii)*[SSS(2,2,ii) -SSS(1,2,ii); -SSS(2,1,ii) SSS(1,1,ii)];
    ll(ii)=log(MS(ii))+[conj(JX(ii)+1i*JY(ii)) conj(JX(ii)-1i*JY(ii))]*MSI*[JX(ii)+1i*JY(ii);JX(ii)-1i*JY(ii)];
end
out=real(sum(ll(2:MF)));
% out=real(0.5*ll(1)+sum(ll(2:MF)));